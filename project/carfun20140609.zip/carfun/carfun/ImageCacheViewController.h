//
//  ImageCacheViewController.h
//  carfun
//
//  Created by Piosa on 14-3-10.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ResourceContainer.h"
@interface ImageCacheViewController : UIViewController

@property (nonatomic, retain) NSOperationQueue      *requsetImageQueue;

@end
