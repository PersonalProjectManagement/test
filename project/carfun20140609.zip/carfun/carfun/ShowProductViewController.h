//
//  ShowProductViewController.h
//  carfun
//
//  Created by Piosa on 14-3-10.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "sys/utsname.h"

@interface ShowProductViewController : UIViewController<UIScrollViewDelegate>
{
    float textHeight;
    
    CGRect imgFrame;
    
    CGRect textContainerFrame;
    
    CGRect secondPageFrame;
    
    //控制切换也
    BOOL displayNextPage;
    
    //到达第二页后
    BOOL arrivedSecondPage;
    
    
    //第一页的位置
    float firstPagePos;
}

@end
