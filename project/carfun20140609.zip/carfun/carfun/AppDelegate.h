//
//  AppDelegate.h
//  carfun
//
//  Created by Piosa on 14-3-7.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIDownloadCache.h"
#import "IndexViewController.h"
//定义改宏变量用于全局可以访问该类
#define SharedApp ((AppDelegate *)[[UIApplication sharedApplication] delegate])

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    
}
@property (strong, nonatomic) UIWindow *window;

@property (nonatomic, retain) ASIDownloadCache *downloadCache;

@property BOOL isHengPing;

@property BOOL isSuuportPortraint;


//该变量记录是否需要转屏
@property BOOL isNeedToChangeOrientation;


//左菜单数据
//第一层的数据
@property(strong,nonatomic) NSMutableArray *dataA;

//第二层的数据
@property(strong,nonatomic) NSMutableDictionary *dataB;

//第三层的数据
@property(strong,nonatomic) NSMutableDictionary *dataC;


@end
