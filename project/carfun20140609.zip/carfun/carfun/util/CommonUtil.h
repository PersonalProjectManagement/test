//
//  CommonUtil.h
//  carfun
//
//  Created by Piosa on 14-3-7.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommonUtil : NSObject
//----------------------
//根据传入的图片设置按钮背景
//----------------------
+(void)setBgOnBtn:(UIButton *)btn withImage:(NSArray *)imgs;


//该方法根据传入的字体等参数返回高度
+(float)getTxtHeight:(NSString *)content forContentWidth:(float)content_width fotFontSize:(float)fontSize;

//得到线
+(UIView *)getLine:(CGRect)frame withLineColor:(UIColor *)borderColor;

//-------------------------------------------------------
//------公用部分
//--------------------------------------------------------
-(void)setBgs:(UIButton *)item withImgName:(NSArray *)imgs;

-(void)setBg:(UIButton *)item withImgName:(NSString *)imgName;


//图片旋转
-(UIImage *)rotateImage:(UIImage *)aImage withImageOrientationi:(UIImageOrientation)orient;

@end
