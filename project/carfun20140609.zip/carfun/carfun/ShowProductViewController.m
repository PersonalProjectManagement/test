//
//  ShowProductViewController.m
//  carfun
//
//  Created by Piosa on 14-3-10.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "ShowProductViewController.h"

@interface ShowProductViewController ()
{
    UIScrollView *main;
    UIScrollView *textContainer;
    UIImageView *right_img;
    
    UIImageView *secondPage;
}

@end

@implementation ShowProductViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

/*!
 *  get the information of the device and system
 *  "i386"          simulator
 *  "iPod1,1"       iPod Touch
 *  "iPhone1,1"     iPhone
 *  "iPhone1,2"     iPhone 3G
 *  "iPhone2,1"     iPhone 3GS
 *  "iPad1,1"       iPad
 *  "iPhone3,1"     iPhone 4
 *  @return null
 */

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    displayNextPage=YES;
	// Do any additional setup after loading the view.
    [self loadPage];
    
    UIDevice *device=[UIDevice currentDevice];
    NSLog(@"device==>%@",device.systemVersion);
    
    
    struct utsname systemInfo;
    uname(&systemInfo);
    
    NSLog(@"===>%@", [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding]);
    NSLog(@"%@", [[UIDevice currentDevice] systemVersion]);
    
}

-(void)loadPage
{
    NSString *content=@"据了解伐啦手机福利房间爱师傅家里发生了地方就爱上法律纠纷拉丝级东方爱上了房间爱死了的发髻上对方拉数据东方阿双方家里附近阿萨德路附近阿萨德飞啦打飞机阿芙拉经费的拉动交罚款了几分拉到几分拉上点访问积分外婆去偶就佛iqjwpfjfnbgapfjfaslfjaslf据了解伐啦手机福利房间爱师傅家里发生了地方就爱上法律纠纷拉丝级东方爱上了房间爱死了的发髻上对方拉数据东方阿双方家里附近阿萨德路附近阿萨德飞啦打飞机阿芙拉经费的拉动交罚款了几分拉到几分拉上点访问积分外婆去偶就佛iqjwpfjfnbgapfjfaslfjaslf据了解伐啦手机福利房间爱师傅家里发生了地方就爱上法律纠纷拉丝级东方爱上了房间爱死了的发髻上对方拉数据东方阿双方家里附近阿萨德路附近阿萨德飞啦打飞机阿芙拉经费的拉动交罚款了几分拉到几分拉上点访问积分外婆去偶就佛iqjwpfjfnbgapfjfaslfjaslf据了解伐啦手机福利房间爱师傅家里发生了地方就爱上法律纠纷拉丝级东方爱上了房间爱死了的发髻上对方拉数据东方阿双方家里附近阿萨德路附近阿萨德飞啦打飞机阿芙拉经费的拉动交罚款了几分拉到几分拉上点访问积分外婆去偶就佛iqjwpfjfnbgapfjfaslfjaslf据了解伐啦手机福利房间爱师傅家里发生了地方就爱上法律纠纷拉丝级东方爱上了房间爱死了的发髻上对方拉数据东方阿双方家里附近阿萨德路附近阿萨德飞啦打飞机阿芙拉经费的拉动交罚款了几分拉到几分拉上点访问积分外婆去偶就佛iqjwpfjfnbgapfjfaslfjaslf据了解伐啦手机福利据了解伐啦手机福利房间爱师傅家里发生了地方就爱上法律纠纷拉丝级东方爱上了房间爱死了的发髻上对方拉数据东方阿双方家里附近阿萨德路附近阿萨德飞啦打飞机阿芙拉经费的拉动交罚款了几分拉到几分拉上点访问积分外婆去偶就佛iqjwpfjfnbgapfjfaslfjaslf据了解伐啦手机福利房间爱师傅家里发生了地方就爱上法律纠纷拉丝级东方爱上了房间爱死了的发髻上对方拉数据东方阿双方家里附近阿萨德路附近阿萨德飞啦打飞机阿芙拉经费的拉动交罚款了几分拉到几分拉上点访问积分外婆去偶就佛iqjwpfjfnbgapfjfaslfjaslf据了解伐啦手机福利房间爱师傅家里发生了地方就爱上法律纠纷拉丝级东方爱上了房间爱死了的发髻上对方拉数据东方阿双方家里附近阿萨德路附近阿萨德飞啦打飞机阿芙拉经费的拉动交罚款了几分拉到几分拉上点访问积分外婆去偶就佛iqjwpfjfnbgapfjfaslfjaslf据了解伐啦手机福利房间爱师傅家里发生了地方就爱上法律纠纷拉丝级东方爱上了房间爱死了的发髻上对方拉数据东方阿双方家里附近阿萨德路附近阿萨德飞啦打飞机阿芙拉经费的拉动交罚款了几分拉到几分拉上点访问积分外婆去偶就佛iqjwpfjfnbgapfjfaslfjaslf";
    UIFont *font=[UIFont systemFontOfSize:14];
    
    //图片宽度
    float img_w=160;
    
    float labelW=ScreenHeight-img_w;
    
   // CGSize size=[content sizeWithAttributes:attributes];;
    
    CGSize sizee = [content sizeWithFont:font
                     constrainedToSize:CGSizeMake(labelW, CGFLOAT_MAX)
                         lineBreakMode:NSLineBreakByWordWrapping];
    textHeight=(sizee.height );
    
    
    //主滚动条
    main=[[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, ScreenHeight, ScreenWidth)];
    main.backgroundColor=[UIColor greenColor];
    main.scrollEnabled=YES;
    main.delegate=self;
  //  main.pagingEnabled=YES;
    [self.view addSubview:main];
    
    NSLog(@"size.height=%f",textHeight);
    
    //左面文本栏目
    
    UILabel *label=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, labelW, textHeight)];
    label.numberOfLines=0;
    label.backgroundColor=[UIColor redColor];
    label.text=content;
    label.font=font;
    
    
    //左面文本栏目滚动条
    textContainerFrame=CGRectMake(0, 0, labelW, ScreenWidth);
    
    textContainer=[[UIScrollView alloc]initWithFrame:textContainerFrame];
    textContainer.backgroundColor=[UIColor yellowColor];
    textContainer.scrollEnabled=NO;
   // textContainer.delegate=self;
    textContainer.showsVerticalScrollIndicator=NO;
    [textContainer addSubview:label];
    textContainer.backgroundColor=[UIColor blueColor];
    
    textContainer.contentSize=CGSizeMake(labelW, textHeight);
    [main addSubview:textContainer];
    
    //右面显示图片
    
    imgFrame=CGRectMake(labelW, 0, img_w, ScreenWidth);
    right_img=[[UIImageView alloc]initWithFrame:imgFrame];
    right_img.image=[UIImage imageNamed:@"bbb.jpeg"];
    [main addSubview:right_img];
    
   
    
    //添加下一页视图
    
    secondPageFrame=CGRectMake(0, textHeight, ScreenHeight, ScreenWidth);
    secondPage=[[UIImageView alloc]initWithFrame:secondPageFrame];
    [main addSubview:secondPage];
    secondPage.image=[UIImage imageNamed:@"aa.jpeg"];
    
    
     main.contentSize=CGSizeMake(ScreenHeight, textHeight+ScreenWidth);
    
    
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView;
{
    NSLog(@"-x->%f  y=%f   textHeight=%f",scrollView.contentOffset.x,scrollView.contentOffset.y,textHeight);
    
    float y=scrollView.contentOffset.y;
    
    //文本可以滚动的高度，然后进行切换
    float maxHeight=(textHeight-ScreenWidth);
    
    firstPagePos=(maxHeight-ScreenWidth);
    
    if (y>maxHeight+10)
    {
        if (displayNextPage)
        {
            displayNextPage=NO;
             [main setContentOffset:CGPointMake(0, textHeight) animated:YES];
        }else
        {
            if ((int)y==(int)textHeight)
            {
                arrivedSecondPage=YES;
            }
            
            if (y<(textHeight-10)&&arrivedSecondPage)
            {
                arrivedSecondPage=NO;
                 [main setContentOffset:CGPointMake(0, firstPagePos) animated:YES];
            }
        }
        
    }else
    {
        if ((int)y==(int)firstPagePos)
        {
            displayNextPage=YES;
        }
        //main.contentOffset=CGPointMake(0, 0);
        float xscale=y/ScreenWidth*50;
        
        right_img.frame=CGRectMake(imgFrame.origin.x-xscale, y, imgFrame.size.width, imgFrame.size.height);
        
         textContainer.frame=CGRectMake(textContainerFrame.origin.x, y, textContainerFrame.size.width, textContainerFrame.size.height);
        
        textContainer.contentOffset=CGPointMake(0, y);
   }
    
}

// called on start of dragging (may require some time and or distance to move)
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
 NSLog(@"-x->%f  y=%f",scrollView.contentOffset.x,scrollView.contentOffset.y);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
