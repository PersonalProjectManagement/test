//
//  EffectViewController.m
//  carfun
//
//  Created by Piosa on 14-5-21.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "EffectViewController.h"

@interface EffectViewController ()

@end

@implementation EffectViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSString *str=@"中新网5月21日电 亚信第四次峰会21日上午在上海举行第一阶段会议，中国国家主席习近平主持并作主旨讲话。他在开场讲话中表示，亚信的发展历程说明，其倡导的加强多边领域信任措施的理念，符合时代发展潮流，契合亚洲各国的安全诉求。习近平表示，日前，土耳其发生煤矿爆炸事故，造成重大人员伤亡，老挝军机失事造成老挝多位领导人不幸遇难。我谨代表中国政府和人民以及所有出席本次峰会的国家和国际组织，向上述两起不幸事件遇难者，表示深切的哀悼！对土耳其和老挝人民表示诚挚的慰问！习近平说，安全是人类生存的基本需求。冷战结束后，和平与发展成为时代主题，但人类面对的安全威胁却有增无减。当前在传统安全威胁和非传统安全威胁交织影响下，不少国家面临安全困境加剧、发展瓶颈突出、社会治理失衡等一系列综合性难题的困扰。如何消除安全威胁，有效应对各类安全挑战，营造一个彼此放心的安全环境，已经成为摆在各位面前的突出问题。";
    
  //  effectView=[[EffectView alloc]initWithFrame:CGRectMake(0, 0, ScreenHeight, ScreenWidth) withData:@[@"biz.png",str]];
    
    [self.view addSubview:effectView];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
