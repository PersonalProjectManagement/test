//
//  AppDelegate.m
//  carfun
//
//  Created by Piosa on 14-3-7.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate
@synthesize dataA;
@synthesize dataB;
@synthesize dataC;
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    
    //---------------
    //左菜单
    //---------------
    
    [self initData];
    
    
    //------------------
    //图片缓存
    //-------------------
    //初始化ASIDownloadCache缓存对象
    ASIDownloadCache *cache = [[ASIDownloadCache alloc] init];
    self.downloadCache = cache;
    
    //路径
    NSArray *paths =NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    NSString *documentDirectory = [paths objectAtIndex:0];
    //设置缓存存放路径
    [self.downloadCache setStoragePath:[documentDirectory stringByAppendingPathComponent:@"resource"]];
    
    //设置缓存策略
    [self.downloadCache setDefaultCachePolicy:ASIOnlyLoadIfNotCachedCachePolicy];
    
    
    
      [application setStatusBarHidden:YES];
    
    
    
    
    return YES;
}





- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


//#if __IPAD_OS_VERSION_MAX_ALLOWED >= __IPAD_6_0
//
//- (NSUInteger)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
//{
//    
//    return UIInterfaceOrientationMaskAll;
//    
//    
//} 
//#endif



-(NSUInteger)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
{
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
        return UIInterfaceOrientationMaskAll;
    else
    { /* iphone */
  
         
       return  UIInterfaceOrientationMaskAllButUpsideDown;
         
    }

}



-(void)initData
{
    //第一级菜单的数据
    dataA=[[NSMutableArray alloc]initWithCapacity:5];
    NSMutableDictionary *item1=[[NSMutableDictionary alloc]initWithCapacity:2];
    [item1 setObject:@"chemizhan.png" forKey:data_name];
    [item1 setObject:CHEMIZHAN_MENU_ITEM forKey:data_key];
    
    NSMutableDictionary *item2=[[NSMutableDictionary alloc]initWithCapacity:2];
    [item2 setObject:@"sracer.png" forKey:data_name];
    [item2 setObject:SRrcer_MENU_ITEM forKey:data_key];
    
    NSMutableDictionary *item3=[[NSMutableDictionary alloc]initWithCapacity:2];
    [item3 setObject:@"BGs.png" forKey:data_name];
    [item3 setObject:BC_MENU_ITEM forKey:data_key];
    
    NSMutableDictionary *item4=[[NSMutableDictionary alloc]initWithCapacity:2];
    [item4 setObject:@"bg.png" forKey:data_name];
    [item4 setObject:BC_OTHER_MENU_ITEM forKey:data_key];
    
    NSMutableDictionary *item5=[[NSMutableDictionary alloc]initWithCapacity:2];
    [item5 setObject:@"take_photo.png" forKey:data_name];
    [item5 setObject:CAMERA_MENU_ITEM forKey:data_key];
    
    
    NSMutableDictionary *item6=[[NSMutableDictionary alloc]initWithCapacity:2];
    [item6 setObject:@"xw.png" forKey:data_name];
    [item6 setObject:INDEX_NEWS_ITEM forKey:data_key];
    
    
    [dataA addObject:item1];
    [dataA addObject:item2];
    [dataA addObject:item3];
    [dataA addObject:item4];
    [dataA addObject:item5];
    [dataA addObject:item6];
    
    MenuData *menuData=[[MenuData alloc]init];
    //第二级菜单的数据
    dataB=[[NSMutableDictionary alloc]initWithCapacity:2];
    
    [dataB setObject:[menuData cheMiZhanMenu] forKey:CHEMIZHAN_MENU_ITEM];
    
    [dataB setObject:[menuData SRrcerMenuData] forKey:SRrcer_MENU_ITEM];
    
    [dataB setObject:[menuData BCData] forKey:BC_MENU_ITEM];
    
    [dataB setObject:[menuData BCOtherMenuData] forKey:BC_OTHER_MENU_ITEM];
    
    
    //
    
    
    dataC=[[NSMutableDictionary alloc]initWithCapacity:5];
    
    
}





@end
