//
//  MapViewController.m
//  carfun
//
//  Created by Piosa on 14-4-3.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "MapViewController.h"

@interface MapViewController ()

@end

@implementation MapViewController
@synthesize mapView;
- (void)viewDidLoad
{
    [super viewDidLoad];
	//（1）创建MKMapView
    CGRect rect = CGRectMake(0, 0, ScreenHeight, ScreenWidth);
    mapView = [[MKMapView alloc] initWithFrame:rect];
    mapView.delegate=self;
    //（2）设定经纬度
    CLLocationCoordinate2D theCoordinate;
    theCoordinate.latitude=24.138727;
    theCoordinate.longitude=120.713827;
    //（3）设定显示范围
    MKCoordinateSpan theSpan;
    theSpan.latitudeDelta=0.1;
    theSpan.longitudeDelta=0.1;
    // （4）设置地图显示的中心及范围
    MKCoordinateRegion theRegion;
    theRegion.center=theCoordinate;
    theRegion.span=theSpan;
    //    （5）设置地图显示的类型及根据范围进行显示
    [mapView setMapType:MKMapTypeStandard];
    [mapView setRegion:theRegion];
    
    //设置注解
    Annotation *annotation1=[[Annotation alloc]init];
    annotation1.title=@"happy";
    annotation1.subtitle=@"hi!";
    annotation1.coordinate=theCoordinate;
    
    
    
    
    
    [self.view addSubview:mapView];
    
    
    //////////////
    //初始化详情弹出框对象
    MKPointAnnotation *pointAnnotation = [[MKPointAnnotation alloc] init];
    //位置
    pointAnnotation.coordinate = theCoordinate;
    
    pointAnnotation.title=@"xxx";
    pointAnnotation.subtitle=@"jflajf";
    
    [mapView addAnnotation:pointAnnotation];
    
    
    [self addLeftMenu];
    
}


- (MKAnnotationView *)mapView:(MKMapView *)mView viewForAnnotation:(id <MKAnnotation>)annotation
{
    
    //系统自带的大头针
    static NSString *AnnotationIdentifier = @"AnnotationIdentifier";
    MKPinAnnotationView *customPinView = (MKPinAnnotationView *)[mView
                                                                 dequeueReusableAnnotationViewWithIdentifier:AnnotationIdentifier];
    
    //自定义标记
    MKAnnotationView *annotationView1=[[MKAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:@"1"];
    
    annotationView1.frame=CGRectMake(0, 0, 30, 30);
    
    annotationView1.image=[UIImage imageNamed:@"little_tree.jpg"];
    annotationView1.canShowCallout=YES;
    
    UIView *left=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 20, 20)];
    left.backgroundColor=[UIColor blueColor];
    
    UIView *right=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 20, 20)];
    right.backgroundColor=[UIColor blueColor];
    
    annotationView1.leftCalloutAccessoryView=left;
    annotationView1.rightCalloutAccessoryView=right;
    
    /**
     @property (nonatomic, retain) UIImage *image
     自定义在地图上标注的图片
     @property (nonatomic) BOOL canShowCallout
     设置点击后能否弹出标注
     @property (retain, nonatomic) UIView *rightCalloutAccessoryView
     property (retain, nonatomic) UIView *leftCalloutAccessoryView
     设置在标注的左右边点击后进一步弹出附属的View
     
     **/
    
    
    return customPinView;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
