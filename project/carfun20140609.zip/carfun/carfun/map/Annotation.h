//
//  Annotation.h
//  map
//
//  Created by Piosa on 13-6-7.
//  Copyright (c) 2013年 com.jdtx. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
#import <CoreLocation/CoreLocation.h>

@interface Annotation : NSObject<MKAnnotation>

//标注必须实现这个协议，有三个属性，coordinate，title和subtitle，其中coordinate属性必须设置。
@property(nonatomic)  CLLocationCoordinate2D coordinate;

// Title and subtitle for use by selection UI.
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subtitle;

@end
