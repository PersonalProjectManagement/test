//
//  ImageCacheViewController.m
//  carfun
//
//  Created by Piosa on 14-3-10.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "ImageCacheViewController.h"

@interface ImageCacheViewController ()

@end

@implementation ImageCacheViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    self.requsetImageQueue=[[NSOperationQueue alloc]init];
    
    NSURL *url = [NSURL URLWithString:@"http://imgcity.ucai.com//default/"];
    
    NSURL *imageURL=nil;
    
    //这个是从器返回有图片数目，self.xxxx根据具体的场合
    NSArray *urls=@[@"郑州.jpg",@"北京.jpg",@"深圳.jpg",@"广州.jpg"];
    
    for (int i=0; i<urls.count;i++)
    {
        
        NSString *str1 = urls[i];
        
          imageURL = [url URLByAppendingPathComponent:str1];
        
        //根据图片号请求资源
        
        [self displayImageByIndex:i ByImageURL: imageURL];
        
    }

}



//根据图片序号显示请求图片资源

-(void)displayImageByIndex:(NSInteger)index ByImageURL:(NSURL *)url
{
    NSString *indexForString = [NSString stringWithFormat:@"%d",index];
    //若数组中已经存在该图片编号，说明图片加载完毕，直接返回
    /** if ([self.originalIndexArray containsObject:indexForString]) {
     return;
     }**/
    
    //创建UIImageView对象
    UIImageView *imageView = [[UIImageView alloc] init];
    imageView.tag = index;
    
    //创建资源请求对象
    ResourceContainer  *imageOperation = [[ResourceContainer alloc] init];
    imageOperation.resourceURL = url;
    imageOperation.hostObject = self;
    
    //设置收到图片信息处理理方法
    imageOperation.resourceDidReceive = @selector(imageDidReceive:);
    imageOperation.imageView = imageView;
    
    
    //将图片请求对象加入图片请求队列中
    [self.requsetImageQueue addOperation:imageOperation];
    // [self.originalOperationDic setObject:imageOperation forKey:indexForString];
    
}

//处理图片请求返回信息

-(void)imageDidReceive:(UIImageView *)imageView
{
    if (imageView == nil||imageView.image == nil) {
        imageView.image = [UIImage imageNamed:@"testa.jpg"];
    }
    
    //将图片信息加载到前台，self.openFlowView是我用的coverFlow，coverFlow的使用方法网上很多，自己找吧
    //[self.openFlowView setImage:imageView.image forIndex:imageView.tag];
    
    imageView.frame=CGRectMake(1, 100*imageView.tag, 100, 90);
    [self.view addSubview:imageView];
    
    //   [self.originalOperationDic removeObjectForKey:[NSString stringWithFormat:@"%d",imageView.tag]];
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
