//
//  EffectView.m
//  carfun
//
//  Created by Piosa on 14-5-21.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "EffectView.h"

@implementation EffectView

-(id)initWithFrame:(CGRect)frame withProductImgFrame:(CGRect)pimgFrame  withData:(NSArray *)_params
{
    params=_params;
    productImgFrame=pimgFrame;
    return [self initWithFrame:frame];
}


- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        scrollViewMoveUpY=100;
        
        [self initView];
        
    }
    return self;
}

/*
 
 */

//初始化视图
-(void)initView
{
    
    
    //背景视图
    bgView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame))];
    bgView.image=[UIImage imageNamed:@"detail_bg.png"];
    [self addSubview:bgView];
    
    //产品图片
    float w=150;
    float h=280;
    float paddingRight=30;
    float x=ScreenHeight-w-paddingRight;
    float y=(ScreenWidth-h)/2;
    
    //productImgFrame=CGRectMake(x, y,w, h);
    
    defaultImgX=productImgFrame.origin.x;
    
    productImage=[[UIImageView alloc]initWithFrame:productImgFrame];
    productImage.image=[UIImage imageNamed:params[0]];
    productImage.backgroundColor=[UIColor clearColor];
    productImage.tag=IMG_TAG;
 
    
    
    //介绍文本
    w=180;
    h=ScreenWidth-100;
    x=80;
    y=30;
    
    UIFont *font=font2;
    
    NSString *descStr=params[1];
    CGSize size=[descStr sizeWithFont:font constrainedToSize:CGSizeMake(w,MAXFLOAT) lineBreakMode:UILineBreakModeWordWrap];
    

    
    lbl=[[UILabel alloc]initWithFrame:CGRectMake(0, 0,w, size.height)];
    lbl.backgroundColor=[UIColor clearColor];
    lbl.numberOfLines=0;
    lbl.font=font;
    lbl.text=descStr;
   
    float qd=x+size.width;
    
    distance=qd;
    
    //文本滚动视图的附加高度
    txtAdditionH=h+h;
    
    //文本滚动视图
    lblScrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(x, y, size.width, h)];
     lblScrollView.contentSize=CGSizeMake(size.width,  size.height+txtAdditionH);
    lblScrollView.tag=TXT_TAG;
    lblScrollView.backgroundColor=[UIColor clearColor];
    lblScrollView.scrollEnabled=YES;
    [lblScrollView addSubview:lbl];
    [self addSubview:lblScrollView];
    
     float ch=size.height+100;
    
    
    imgRate=(productImgFrame.origin.x-qd)/(size.height-h);
    
    NSLog(@"imageRate=>%f",imgRate);
    
    
    //滚动视图
    scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame))];
    scrollView.showsVerticalScrollIndicator=NO;
    scrollView.scrollEnabled=YES;
    scrollView.delegate=self;
    
   
    
    scrollView.contentSize=CGSizeMake(CGRectGetWidth(scrollView.frame), ch);
    [self addSubview:scrollView];
    
    
  
   
       [self addSubview:productImage];
    
    //背景视图
    
    //滚动视图
    
    //产品介绍文本在滚动视图上

    //产品图片在背景视图上，当滚动视图滚动的时候，产品图片往左移动
    
}


- (void)scrollViewDidScroll:(UIScrollView *)scrollViews
{
    float cy=scrollViews.contentOffset.y;
    
   // NSLog(@"cy=%f",cy);
    
    lblScrollView.contentOffset=CGPointMake(0, cy);
    
    
    float x=productImgFrame.origin.x-cy*imgRate;
    
    productImage.frame=CGRectMake(x, productImgFrame.origin.y, CGRectGetWidth(productImgFrame), CGRectGetHeight(productImgFrame));
    
}



//设置图片到文字的右面
-(void)setProductImgDefault
{
    productImage.frame=productImgFrame;
    scrollView.contentOffset=CGPointMake(0, 0);
}

//根据传入的y坐标移动文本和图片,当第1页切换到第2页的时候
-(void)moveUp:(float)y
{
    float oy=y;
    
    if (y>ScreenWidth)
    {
        y=(oy-ScreenWidth);
    }
    
    
    
    //图片移动距离向上滑动的比例
    float rate=((distance)/ScreenWidth);
    
    //图片向右移动
    productImage.frame=CGRectMake(rate*(ScreenWidth-y), productImgFrame.origin.y, CGRectGetWidth(productImgFrame), CGRectGetHeight(productImgFrame));
    
    //文本向下滑动
    
    //文本高度
    
    rate=(txtAdditionH/4)/ScreenWidth;
    
    //得到未滑动到第二页的位置
    float currentY=lblScrollView.contentSize.height-txtAdditionH-lblScrollView.frame.size.height;
    
  //  NSLog(@"lblScrollView=>%f   currentY=%f",,currentY);
    
    //文本滚动视图在之前的位置上加
    float addH=(y*rate);
    
    
    lblScrollView.contentOffset=CGPointMake(0,(currentY+addH));
    
}




//根据传入的y坐标移动文本和图片,当第二页切换到第一页的时候
-(void)moveDown:(float)y
{
    float oy=y;
    
    if (oy>ScreenWidth)
    {
         oy=(oy-ScreenWidth);
    }
    
    y=(ScreenWidth-oy);
    
    
    
    //图片移动距离向上滑动的比例
    float rate=((defaultImgX)/ScreenWidth);
    
    //图片向右移动
    productImage.frame=CGRectMake(rate*y, productImgFrame.origin.y, CGRectGetWidth(productImgFrame), CGRectGetHeight(productImgFrame));
    
   
    //滚动文本的高度
    float txtH= lblScrollView.contentSize.height;
    
    rate=(txtH/ScreenWidth);
    
    lblScrollView.contentOffset=CGPointMake(0, txtH-(rate*y));
 
    
    NSLog(@"oy=%f",oy);
    
    if (oy<8)
    {
        scrollView.contentOffset=CGPointMake(0, 0);
        
        lblScrollView.contentOffset=CGPointMake(0, 0);

    }
}


//设置滚动视图的偏移量为0，有坐标向上滚动一段距离
-(void)setScrollViewTxtOffsetAndY
{

}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
