//
//  MyButton.h
//  newBuyTicket
//
//  Created by Piosa on 14-1-17.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyButton : UIButton

@property(nonatomic,strong) NSDictionary *param;
@end
