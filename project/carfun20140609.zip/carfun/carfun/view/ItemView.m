//
//  ItemView.m
//  newBuyTicket
//
//  Created by Piosa on 14-1-17.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "ItemView.h"
 
@implementation ItemView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.bgColor=[UIColor colorWithRed:[self convertColor:39] green:[self convertColor:39] blue:[self convertColor:41] alpha:0.6];
        
        self.backgroundColor=self.bgColor;
       
        
    }
    return self;
}

-(UIColor *)getColorRed:(float)red withY:(float)y withB:(float)b withAlpha:(float)alpha
{
    return [UIColor colorWithRed:[self convertColor:red] green:[self convertColor:y] blue:[self convertColor:b] alpha:[self convertColor:alpha]];
}

-(float)convertColor:(float)v
{
    return (v/255.5);
}

-(void)setList:(NSArray *)list withEvent:(SEL)click_event withObj:(id)obj withItemHeight:(float)itemHeight withDataType:(int)dataType  withIsCamera:(BOOL)isCamera
{
    if (isCamera)
    {
        scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame))];
        [self addSubview:scrollView];
        scrollView.scrollEnabled=YES;
        
        scrollView.showsVerticalScrollIndicator=NO;
        scrollView.contentSize=CGSizeMake(itemHeight*list.count,CGRectGetHeight(self.frame));
        
        borderColor=[self getColorRed:59 withY:59 withB:61 withAlpha:255];
        scrollView.layer.borderColor=[borderColor CGColor];
        scrollView.layer.borderWidth=0.5;
        
        //scrollView.backgroundColor=[UIColor clearColor];
        
        
        sel=click_event;
        self.list=list;
        // float h=self.frame.size.height;
        float w=itemHeight;
        
        float ty=0;
        float item_h=self.frame.size.height;
        
       // CommonUtil *commonUtil=[[CommonUtil alloc]init];
        
        for (int i=list.count-1; i>=0; i--)
        {
            NSDictionary *item_data=list[i];
            
            MyButton *item_btn=[[MyButton alloc]initWithFrame:CGRectMake(ty, 0,w, item_h)];
            item_btn.param=list[i];
            item_btn.tag=i;
            
            if (dataType==IS_IMAGE)
            {
                float btnw=CGRectGetHeight(item_btn.frame);
                float btnh=CGRectGetWidth(item_btn.frame);
                
                
                float bgw=90;
                float bgh=46;
                float bgx=(btnh-bgh)/2;
                float bgy=(btnw-bgw)/2;
                
                
                UIImageView *bg=[[UIImageView alloc]initWithFrame:CGRectMake(bgx, bgy, bgh,bgw)];
                
                NSString *imgName=[[item_data objectForKey:data_name]stringByReplacingOccurrencesOfString:@".png" withString:@"2.png"];
                
                UIImage *image=[UIImage imageNamed:imgName];
                
                
             //   image=[commonUtil rotateImage:image withImageOrientationi:UIImageOrientationRight];
                
                [bg setImage:image];
                [item_btn addSubview:bg];
            }else
            {
                item_btn.frame=CGRectMake(0, ty,item_h, w);
                item_btn.backgroundColor=[UIColor greenColor];
                item_btn.titleLabel.font=[UIFont systemFontOfSize:14];
                [item_btn setTitle:[item_data objectForKey:data_name] forState:UIControlStateNormal];
                item_btn.transform=CGAffineTransformRotate(CGAffineTransformIdentity, 90*(M_PI/180));
                
                [item_btn setTitle:[item_data objectForKey:data_name] forState:UIControlStateHighlighted];
                
                
               
            }
            
            
            //添加分界线
            float lineH=1;
            UIImageView *underline=[[UIImageView alloc]initWithFrame:CGRectMake(CGRectGetWidth(item_btn.frame)-lineH, 0, lineH, CGRectGetHeight(item_btn.frame))];
            [underline setBackgroundColor:INDEX_MENU_DEVIDE_LINE_COLOR];
            [item_btn addSubview:underline];
            
            
            [item_btn addTarget:obj action:sel forControlEvents:UIControlEventTouchUpInside];
            
            item_btn.backgroundColor=[UIColor clearColor];
            
            
            [scrollView addSubview:item_btn];
            
            
            self.stateLine=[[UIView alloc]initWithFrame:CGRectMake((CGRectGetHeight(self.frame)-2), ScreenWidth-itemHeight, itemHeight, 2)];
            self.stateLine.backgroundColor=INDEX_MENU_SELETED_COLOR;
            self.stateLine.hidden=YES;
            [scrollView addSubview:self.stateLine];
            
            
            ty+=w;
        }

        
        
        
        
        //----------------------
    }
    else
    {
    scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame))];
    [self addSubview:scrollView];
    scrollView.scrollEnabled=YES;
    scrollView.showsVerticalScrollIndicator=NO;
    scrollView.contentSize=CGSizeMake(CGRectGetWidth(self.frame), itemHeight*list.count);
    
    borderColor=[self getColorRed:59 withY:59 withB:61 withAlpha:255];
    scrollView.layer.borderColor=[borderColor CGColor];
    scrollView.layer.borderWidth=0.5;
    
    
    sel=click_event;
    self.list=list;
   // float h=self.frame.size.height;
    float w=self.frame.size.width;
    
    float ty=0;
    float item_h=itemHeight;
    
    
    
    for (int i=0; i<list.count; i++)
    {
        NSDictionary *item_data=list[i];
        
        MyButton *item_btn=[[MyButton alloc]initWithFrame:CGRectMake(0, ty, w, item_h)];
        item_btn.param=list[i];
        item_btn.tag=i;
        
        if (dataType==IS_IMAGE)
        {
            float btnw=CGRectGetWidth(item_btn.frame);
            float btnh=CGRectGetHeight(item_btn.frame);
            
            
            float bgw=90;
            float bgh=46;
            float bgx=(btnw-bgw)/2;
            float bgy=(btnh-bgh)/2;
            
            
            UIImageView *bg=[[UIImageView alloc]initWithFrame:CGRectMake(bgx, bgy, bgw, bgh)];
            [bg setImage:[UIImage imageNamed:[item_data objectForKey:data_name]]];
            [item_btn addSubview:bg];
        }else
        {
            item_btn.titleLabel.font=[UIFont systemFontOfSize:14];
            [item_btn setTitle:[item_data objectForKey:data_name] forState:UIControlStateNormal];
            [item_btn setTitle:[item_data objectForKey:data_name] forState:UIControlStateHighlighted];
        }
        
        
        //添加分界线
        float lineH=1;
        UIImageView *underline=[[UIImageView alloc]initWithFrame:CGRectMake(0, CGRectGetHeight(item_btn.frame)-lineH, CGRectGetWidth(item_btn.frame), lineH)];
        [underline setBackgroundColor:INDEX_MENU_DEVIDE_LINE_COLOR];
        [item_btn addSubview:underline];
        
        
        [item_btn addTarget:obj action:sel forControlEvents:UIControlEventTouchUpInside];
        
        
        [scrollView addSubview:item_btn];
        
        
        self.stateLine=[[UIView alloc]initWithFrame:CGRectMake((CGRectGetWidth(self.frame)-2), 0, 2, itemHeight)];
        self.stateLine.backgroundColor=INDEX_MENU_SELETED_COLOR;
        self.stateLine.hidden=YES;
        [scrollView addSubview:self.stateLine];
        
        
        ty+=item_h;
    }

    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
