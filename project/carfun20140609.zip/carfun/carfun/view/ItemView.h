//
//  ItemView.h
//  newBuyTicket
//
//  Created by Piosa on 14-1-17.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyButton.h"
#import "CommonUtil.h"
#define IS_IMAGE  1
#define IS_TEXT   2
@interface ItemView : UIView
{
    SEL sel;
    UIColor *borderColor;
    
    UIViewController *viewController;
    
    UIScrollView *scrollView;
    
    
}
@property(nonatomic,strong) UIColor *bgColor;


@property(nonatomic,strong) NSArray *list;

//当前选中的项标志，采用一个竖线进行移动Y坐标进行控制
@property(nonatomic,strong) UIView *stateLine;


-(void)setList:(NSArray *)list withEvent:(SEL)click_event withObj:(id)obj withItemHeight:(float)itemHeight withDataType:(int)dataType withIsCamera:(BOOL)isCamera;
@end
