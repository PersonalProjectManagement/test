//
//  ViewController.m
//  carfun
//
//  Created by Piosa on 14-3-7.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
{
    
}

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
  
}

- (BOOL)prefersStatusBarHidden
{
    return YES;
}

@end
