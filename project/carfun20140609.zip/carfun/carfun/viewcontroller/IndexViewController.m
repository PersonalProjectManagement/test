
//
//  IndexViewController.m
//  carfun
//
//  Created by Piosa on 14-4-3.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "IndexViewController.h"

@interface IndexViewController ()

@end

@implementation IndexViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)loadView
{
    [super loadView];
//	// Do any additional setup after loading the view.
    self.background=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, ScreenHeight, ScreenWidth)];
  
   [self.background setImage:[UIImage imageNamed:@"index.png"]];
    [self.view addSubview:self.background];
    
    UIDevice *device=[UIDevice currentDevice];
    
    NSDictionary *bundle=[[NSBundle mainBundle] infoDictionary];
    
        
    
    NSLog(@"bundle=%@",bundle.description);
    
    
    UIImageView *v2=[[UIImageView alloc]initWithFrame:CGRectMake(90, 90, 80, 80)];
    v2.image=[UIImage imageNamed:@"aa.jpeg"];
  v2.transform=CGAffineTransformRotate(CGAffineTransformIdentity,180*(M_PI/180));
    [self.view addSubview:v2];
    
    
    //7.0.6
    
    NSLog(@"systemName=%@----systemVersion=%@",device.systemName,device.systemVersion);
    
   /* if ([device.systemVersion isEqualToString:@"7.0.6"])
    {
        if (!SharedApp.isHengPing)
        {
            SharedApp.isNeedToChangeOrientation=YES;
            
            CATransform3D transform = CATransform3DMakeRotation(M_PI / 2, 0, 0, 1.0);
            self.view.layer.transform = transform;
            
            SharedApp.isHengPing=YES;
        }
        
//        if ([[UIDevice currentDevice] respondsToSelector:@selector(setOrientation:)]) {
//            SEL selector = NSSelectorFromString(@"setOrientation:");
//            NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:[UIDevice instanceMethodSignatureForSelector:selector]];
//            [invocation setSelector:selector];
//            [invocation setTarget:[UIDevice currentDevice]];
//            int val = UIInterfaceOrientationLandscapeRight;
//            [invocation setArgument:&val atIndex:2];
//            [invocation invoke];
//        }
        
    }
    
    
    
//    if (!SharedApp.isHengPing)
//     {
//         CATransform3D transform = CATransform3DMakeRotation(M_PI / 2, 0, 0, 1.0);
//          self.view.layer.transform = transform;
// 
//        SharedApp.isHengPing=YES;
//      }
    
//    if ([[UIDevice currentDevice] respondsToSelector:@selector(setOrientation:)]) {
//        SEL selector = NSSelectorFromString(@"setOrientation:");
//        NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:[UIDevice instanceMethodSignatureForSelector:selector]];
//        [invocation setSelector:selector];
//        [invocation setTarget:[UIDevice currentDevice]];
//        int val = UIInterfaceOrientationLandscapeRight;
//        [invocation setArgument:&val atIndex:2];
//        [invocation invoke];
    //}
    
     
    
 **/

      
} 

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


 


@end
