//
//  ParentViewViewController.h
//  carfun
//
//  Created by Piosa on 14-4-3.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "LeftMenuViewController.h"

//产品图片
#define IMAGE_KEY  @"IMAGE_KEY"
//产品名字
#define NAME_KEY   @"NAME_KEY"

@interface ParentViewViewController : LeftMenuViewController<UIScrollViewDelegate>


@property(nonatomic,strong) UIScrollView *scrollView;

//该变量记录第一部分，当文字滑动是产品图片的移动比例
@property float moveScale;

//文本的Frame
@property CGRect detailFrame;

//产品图片的Frame
@property CGRect productImgFrame;

//产品图片
@property(nonatomic,strong) UIImageView *productImgView;

//详细介绍文本滚动视图的高度
@property float scrollH;

@property(nonatomic,strong) NSString *param;



//得到Image视图
-(UIImageView *)getImageView:(CGRect)frame withBg:(NSString *)imageName;

@end
