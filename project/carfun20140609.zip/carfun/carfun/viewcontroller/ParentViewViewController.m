//
//  ParentViewViewController.m
//  carfun
//
//  Created by Piosa on 14-4-3.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "ParentViewViewController.h"

@interface ParentViewViewController ()

@end

@implementation ParentViewViewController

 

- (void)viewDidLoad
{
    [super viewDidLoad];
    
   // [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(changeFrames:)
//                                                 name:UIDeviceOrientationDidChangeNotification
//                                               object:nil];
    
    
	// Do any additional setup after loading the view.
    self.view.backgroundColor=[UIColor whiteColor];
    
    if (SharedApp.isNeedToChangeOrientation)
    {
       //  [self setOriention];
    }
 
}

-(void)changeFrames:(NSNotification *)notification
{
    NSLog(@"change notification: %@", notification.userInfo);
    float width=[[UIScreen mainScreen]bounds].size.width;//*[[UIScreen mainScreen] scale];
    float height=[[UIScreen mainScreen]bounds].size.height;//*[[UIScreen mainScreen] scale];
    if ([[UIDevice currentDevice] orientation]==UIInterfaceOrientationPortrait
        || [[UIDevice currentDevice] orientation]==UIInterfaceOrientationPortraitUpsideDown)
    {
        NSLog(@"portrait");
        self.view.frame=CGRectMake(0, 0, height, width);
    }
    else
    {
        NSLog(@"landscape");
        self.view.frame=CGRectMake(0, 0, width, height);
    }
    NSLog(@"view is %@",self);
}




-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    if (![self.view viewWithTag:MENU_VIEW_TAG])
    {
         [self addLeftMenu];
    }     
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//得到Image视图
-(UIImageView *)getImageView:(CGRect)frame withBg:(NSString *)imageName
{
    UIImageView *firstPartView=[[UIImageView alloc]initWithFrame:frame];
    
    UIImage *image=[UIImage imageNamed:imageName];
    
    firstPartView.image=image;
    return firstPartView;
}


@end
