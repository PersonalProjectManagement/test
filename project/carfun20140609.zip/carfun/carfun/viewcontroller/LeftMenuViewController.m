//
//  LeftMenuViewController.m
//  newBuyTicket
//
//  Created by Piosa on 14-1-17.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "LeftMenuViewController.h"

#import "IndexViewController.h"

#import "ShareImageViewController.h"

#define CHEMIZHAN_MENU_ITEM   @"车迷站"
#define SRrcer_MENU_ITEM      @"SRrcer"
#define BC_MENU_ITEM          @"BC"
#define BC_OTHER_MENU_ITEM    @"BC_OTHER"
#define CAMERA_MENU_ITEM      @"CAMERA"
#define INDEX_NEWS_ITEM       @"INDEX_NEWS_ITEM"

//第一级菜单项的高度
#define FIRST_ITEM_HEIGHT (ScreenWidth/5)

//第2-3级菜单项的高度
#define AFTER_ITEM_HEIGHT (ScreenWidth/9)

#define layer_width   90
#define layer_two_width  120
#define layer_third_width  90
@interface LeftMenuViewController()

@end

@implementation LeftMenuViewController
@synthesize dataA,dataB,dataC,background;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
 

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    self.navigationController.navigationBarHidden = YES;
    
    self.distinguishLbl=[[UILabel alloc]initWithFrame:CGRectMake(30, 30, 350, 50)];
    self.distinguishLbl.font=[UIFont boldSystemFontOfSize:20];
    self.distinguishLbl.textColor=[UIColor redColor];
    
    //self.leftSwipeGestureRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipes:)];
    //self.rightSwipeGestureRecognizer = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipes:)];
    
    //self.leftSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirectionLeft;
    //self.rightSwipeGestureRecognizer.direction = UISwipeGestureRecognizerDirectionRight;
    
   // [self.view addGestureRecognizer:self.leftSwipeGestureRecognizer];
    //[self.view addGestureRecognizer:self.rightSwipeGestureRecognizer];
   
    
}

- (void)handleSwipes:(UISwipeGestureRecognizer *)sender
{
    if (sender.direction != UISwipeGestureRecognizerDirectionLeft)
    {
         NSLog(@"<----");
        [self showLeft];
    }
}


-(void)setOriention
{
    if ([[UIDevice currentDevice] respondsToSelector:@selector(setOrientation:)]) {
        [[UIDevice currentDevice] performSelector:@selector(setOrientation:)
                                       withObject:(id)UIInterfaceOrientationLandscapeRight];
    }
}



//添加左按钮
-(void)addLeftMenu
{
    //背景
    [self initData];
 
    leftFrame=CGRectMake(0, 0,MENU_WIDHT, MENU_HEIGHT);
    left=[[UIButton alloc]initWithFrame:leftFrame];
    [self setBgOnBtn:left withImage:@[@"menu.png",@"menu.png"]];
    [self.view addSubview:left];
    [left addTarget:self action:@selector(showLeft) forControlEvents:UIControlEventTouchUpInside];
    
    
    //初始化视图到界面
    first_grade_frame=CGRectMake(-layer_width, 0, layer_width, ScreenWidth);
    
    defaultFrame= CGRectMake(0, 0, layer_width, ScreenWidth);
    
    //第二层的默认尺寸
    default_second_grade_frame=CGRectMake(-(layer_two_width-layer_width), 0, layer_two_width, ScreenWidth);
    
    //第三层的默认尺寸
    default_three_grade_frame= CGRectMake(0, 0, layer_third_width, ScreenWidth);
    
    layerThree=[[ItemView alloc]initWithFrame:default_three_grade_frame];
    
    layerTwo=[[ItemView alloc]initWithFrame:default_second_grade_frame];
   
    
//    layerTwo.backgroundColor=[UIColor greenColor];
    
    layerOne=[[ItemView alloc]initWithFrame:defaultFrame];
    
    layerThree.alpha=0;
    
    leftContainer=[[UIView alloc]initWithFrame:first_grade_frame];
    
    leftContainer.tag=MENU_VIEW_TAG;
    
    [self.view addSubview:leftContainer];
    
    layerTwo.backgroundColor=[UIColor clearColor];
    layerThree.backgroundColor=[UIColor clearColor];
    
    [leftContainer addSubview:layerThree];
    [leftContainer addSubview:layerTwo];
    [leftContainer addSubview:layerOne];
    
    [layerOne setList:dataA withEvent:@selector(showSecondLayer:) withObj:self withItemHeight:FIRST_ITEM_HEIGHT withDataType:IS_IMAGE withIsCamera:NO];
    
    CGRect rightFrame=CGRectMake((ScreenHeight-CGRectGetWidth(leftFrame)), 0, CGRectGetWidth(leftFrame), CGRectGetHeight(leftFrame));
    self.rightMenu=[[UIButton alloc]initWithFrame:rightFrame];
    self.rightMenu.hidden=YES;
    [self setBgOnBtn:self.rightMenu withImage:@[@"menu.png",@"menu.png"]];
    [self.view addSubview:self.rightMenu];
}



//根据传入的图片设置按钮背景
-(void)setBgOnBtn:(UIButton *)btn withImage:(NSArray *)imgs
{
    [btn setImage:[UIImage imageNamed:imgs[0]] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:imgs[1]] forState:UIControlStateHighlighted];
}

-(void)initData
{
    //第一级菜单的数据
   
    
    dataA=[[NSMutableArray alloc]initWithCapacity:5];
    NSMutableDictionary *item1=[[NSMutableDictionary alloc]initWithCapacity:2];
    [item1 setObject:@"chemizhan.png" forKey:data_name];
    [item1 setObject:CHEMIZHAN_MENU_ITEM forKey:data_key];
    
    NSMutableDictionary *item2=[[NSMutableDictionary alloc]initWithCapacity:2];
    [item2 setObject:@"sracer.png" forKey:data_name];
    [item2 setObject:SRrcer_MENU_ITEM forKey:data_key];
    
    NSMutableDictionary *item3=[[NSMutableDictionary alloc]initWithCapacity:2];
    [item3 setObject:@"BGs.png" forKey:data_name];
    [item3 setObject:BC_MENU_ITEM forKey:data_key];
    
    NSMutableDictionary *item4=[[NSMutableDictionary alloc]initWithCapacity:2];
    [item4 setObject:@"bg.png" forKey:data_name];
    [item4 setObject:BC_OTHER_MENU_ITEM forKey:data_key];
    
    NSMutableDictionary *item5=[[NSMutableDictionary alloc]initWithCapacity:2];
    [item5 setObject:@"take_photo.png" forKey:data_name];
    [item5 setObject:CAMERA_MENU_ITEM forKey:data_key];
    
    
    NSMutableDictionary *item6=[[NSMutableDictionary alloc]initWithCapacity:2];
    [item6 setObject:@"xw.png" forKey:data_name];
    [item6 setObject:INDEX_NEWS_ITEM forKey:data_key];
    
    
    [dataA addObject:item1];
    [dataA addObject:item2];
    [dataA addObject:item3];
    [dataA addObject:item4];
    [dataA addObject:item5];
    [dataA addObject:item6];
    
    MenuData *menuData=[[MenuData alloc]init];
    //第二级菜单的数据
    dataB=[[NSMutableDictionary alloc]initWithCapacity:2];
    
    [dataB setObject:[menuData cheMiZhanMenu] forKey:CHEMIZHAN_MENU_ITEM];
    
    [dataB setObject:[menuData SRrcerMenuData] forKey:SRrcer_MENU_ITEM];
    
    [dataB setObject:[menuData BCData] forKey:BC_MENU_ITEM];
    
     [dataB setObject:[menuData BCOtherMenuData] forKey:BC_OTHER_MENU_ITEM];
    
    
    //
    
    
     dataC=[[NSMutableDictionary alloc]initWithCapacity:5];
 
   
}



-(void)showLeft
{
    if (left.tag!=5)
    {
        left.tag=5;
        [UIView animateWithDuration:1 animations:
         ^{
            left.frame=CGRectMake(layer_width, leftFrame.origin.y, leftFrame.size.width, leftFrame.size.height);
             leftContainer.frame=CGRectMake(0, 0, first_grade_frame.size.width, first_grade_frame.size.height);
         }];
    }else
    {
        [self hideMenu];
    }
}



-(void)hideMenu
{
    left.tag=0;
    
    [UIView animateWithDuration:1 animations:
     ^{
         CGRect tempFrame=leftContainer.frame;
         
         leftContainer.frame=CGRectMake(-tempFrame.size.width, tempFrame.origin.y, tempFrame.size.width, tempFrame.size.height);
         
         leftContainer.alpha=0;
         
         left.frame=leftFrame;
         
         
         
     } completion:^(BOOL finished)
     {
         
         leftContainer.alpha=1;
         layerThree.frame=default_three_grade_frame;
         layerTwo.frame=default_second_grade_frame;
         
         layerOne.frame=defaultFrame;
         
         leftContainer.frame=first_grade_frame;
         //移除第二层和第三层中的所有视图
         [self removeAllSubViews:layerTwo];
         [self removeAllSubViews:layerThree];
         
         //设置第二层和第三层的背景为透明
         layerTwo.backgroundColor=[UIColor clearColor];
         layerThree.backgroundColor=[UIColor clearColor];
         
     }];

}

-(BOOL)prefersStatusBarHidden
{
    return YES;
}


//根据传入的菜单列表设置选中项
-(void)setListCurrentSelectedItem:(ItemView *)itemView withPositionTag:(int)tag
{
    //在按钮的右面添加一条红的竖线
    CGRect tempFrame=itemView.stateLine.frame;
    float x=tempFrame.origin.x;
    float h=tempFrame.size.height;
    float y= (tag*CGRectGetHeight(tempFrame));
    itemView.stateLine.hidden=NO;
    itemView.stateLine.frame=CGRectMake(x,y, 1,h);
}
//展示第二层视图
-(void)showSecondLayer:(MyButton *)sender
{
    
    
    
    if ([[sender.param objectForKey:data_key] isEqualToString:CAMERA_MENU_ITEM])
    {
        CarFanCustomImagePickerControllerViewController *vc=[[CarFanCustomImagePickerControllerViewController alloc] init];
        vc.uiViewController=self;
        
        [self hideMenu];
        
       [self pushToTakePhoto:vc];

    }else
    {
        leftContainer.frame=CGRectMake(0, 0, layer_width+layer_two_width, ScreenWidth);
        
        
        NSArray *dataList=[dataB objectForKey:[sender.param objectForKey:data_key]];
        
        [self deleteAllSubView:layerTwo];
        
        /*
         //在按钮的右面添加一条红的竖线
         CGRect tempFrame=layerOne.stateLine.frame;
         float x=tempFrame.origin.x;
         float h=tempFrame.size.height;
         float y= (sender.tag*CGRectGetHeight(tempFrame));
         layerOne.stateLine.hidden=NO;
         layerOne.stateLine.frame=CGRectMake(x,y, 2,h);
         */
        
        [self setListCurrentSelectedItem:layerOne withPositionTag:sender.tag];
        
        layerTwo.backgroundColor=layerTwo.bgColor;
        
        [layerTwo setList:dataList withEvent:@selector(showThirdLayer:)  withObj:self withItemHeight:AFTER_ITEM_HEIGHT withDataType:IS_TEXT withIsCamera:NO] ;
        
        
        if (layerThree.alpha>0)
        {
            layerThree.alpha=0;
            
            layerTwo.frame=CGRectMake(layer_width, 0, layer_two_width, ScreenWidth);
            
            layerThree.frame=CGRectMake(layerTwo.frame.origin.x, layerTwo.frame.origin.y, layer_third_width, ScreenWidth);
            
            left.frame=CGRectMake(layer_width+layer_two_width, leftFrame.origin.y, leftFrame.size.width, leftFrame.size.height);
        }else
        {
            layerTwo.alpha=0.2;
            [UIView animateWithDuration:1 animations:
             ^{
                 layerTwo.alpha=1;
                 
                 layerTwo.frame=CGRectMake(layer_width, 0, layer_two_width, ScreenWidth);
                 
                 layerThree.frame=CGRectMake(layerTwo.frame.origin.x+(layer_two_width-layer_third_width), layerTwo.frame.origin.y, layer_third_width, ScreenWidth);
                 
                 left.frame=CGRectMake(layer_width+layer_two_width, leftFrame.origin.y, leftFrame.size.width, leftFrame.size.height);
             }];
            
        }
        

    }
    
    
}

//跳转到照相页面
-(void)pushToTakePhoto:(CarFanCustomImagePickerControllerViewController *)imagePickerController
{
    self.navigationItem.hidesBackButton = YES;
    
    self.imagePickerController = imagePickerController;
    self.imagePickerController.externalNavgation=self.navigationController;
    
    self.imagePickerController.allowsEditing = NO;
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
        self.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera; //if there is a camera avaliable
    } else {
        self.imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;//otherwise go to the folder
    }
    //self.imagePickerController.mediaTypes = [[NSArray alloc] initWithObjects: (NSString *) kUTTypeImage, nil];
    
    if (self.imagePickerController.sourceType == UIImagePickerControllerSourceTypeCamera)
    {
        self.imagePickerController.showsCameraControls = NO;
        
        
        //    self.imagePickerController.cameraViewTransform = CGAffineTransformMakeRotation(M_PI/2);
        
        // self.imagePickerController.cameraOverlayView = [self buildOverlay];
        
        
        // Device's screen size (ignoring rotation intentionally):
        CGSize screenSize = [[UIScreen mainScreen] bounds].size;
        
        int heightOffset = 0;
        
        UIDevice *device=[UIDevice currentDevice];
        
        if([device.systemVersion rangeOfString:@"7"].location!=NSNotFound)
        {
            heightOffset = 120; //whole screen :)
        }
        
        float cameraAspectRatio = 4.0 / 3.0; //! Note: 4.0 and 4.0 works
        float imageWidth = floorf(screenSize.width * cameraAspectRatio);
        //float scale = ceilf(((screenSize.height + heightOffset) / imageWidth) * 10.0) / 10.0;
        
        
        // self.imagePickerController.cameraViewTransform = CGAffineTransformMakeScale(scale, scale);
        
        [self presentViewController:self.imagePickerController animated:YES completion:NULL];
        
        
        //            ShareImageViewController *vc=[[ShareImageViewController alloc]init];
        //            [self.navigationController pushViewController:vc animated:YES];
        
    }

}

-(UIView *)buildOverlay
{
    UIView *v=[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenHeight, 40)];
    
    v.backgroundColor=[UIColor colorWithRed:0.2 green:0.3 blue:0.5 alpha:0.3];
    return v;
}


-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    [self hideMenu];
}


//根据传入的视图删除其中的所有子视图
-(void)deleteAllSubView:(UIView *)parent
{
    NSArray *views=[parent subviews];
    
    for (UIView *v in views)
    {
        [v removeFromSuperview];
    }

}

//展示第三层视图
-(void)showThirdLayer:(MyButton *)sender
{
   // layerThree.alpha=0;
    
    NSDictionary *data_item=sender.param;
    
    //得到第三层菜单数据
    NSArray *dataList=[data_item objectForKey:next_menu_list];
    
    if (dataList)
    {
        leftContainer.frame=CGRectMake(0, 0, layer_width+layer_two_width+layer_third_width, ScreenWidth);
        
        //删除说有的子视图
        [self deleteAllSubView:layerThree];
        
        [self setListCurrentSelectedItem:layerTwo withPositionTag:sender.tag];
        layerThree.backgroundColor=layerThree.bgColor;
        [layerThree setList:dataList withEvent:@selector(specify:)  withObj:self withItemHeight:AFTER_ITEM_HEIGHT withDataType:IS_TEXT withIsCamera:NO];
        
        layerThree.alpha=0.2;
        [UIView animateWithDuration:1 animations:
         ^{
             layerThree.alpha=1;
             
             
             
             layerThree.frame=CGRectMake(layer_width+layer_two_width, 0, layer_width, ScreenWidth);
             left.frame=CGRectMake(layer_width+layer_two_width+layer_third_width, leftFrame.origin.y, leftFrame.size.width, leftFrame.size.height);
         }];

    }else
    {
        UIViewController *viewController=[data_item objectForKey:key_to_vc];
        if (viewController)
        {
            [self.navigationController pushViewController:viewController animated:YES];
        }else
        {
            //隐藏第三层
            [UIView animateWithDuration:1 animations:
             ^{
                 layerThree.alpha=0;
                 
                 layerThree.frame=CGRectMake(layerTwo.frame.origin.x+layer_two_width-layer_third_width, 0, layer_third_width, ScreenWidth);
                 
                 
                 
                 left.frame=CGRectMake(layer_width+layer_two_width, leftFrame.origin.y, leftFrame.size.width, leftFrame.size.height);
             }];
            
            
            
        }
    }
    
    
}

//根据传入的视图清空里面所有的子视图
-(void)removeAllSubViews:(UIView *)view
{
    NSArray *vs=[view subviews];
    for (int i=0; i<vs.count; i++) {
        UIView *v=vs[i];
        [v removeFromSuperview];
    }
}


-(void)specify:(MyButton *)sender
{
    NSLog(@"--->%d",sender.tag);
    
    UIViewController *viewController=[sender.param objectForKey:key_to_vc];
    
    if (viewController)
    {
        [self.navigationController pushViewController:viewController animated:YES];
    }
    
}




//该方法根据传入的位置和数据提供一个视图

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
