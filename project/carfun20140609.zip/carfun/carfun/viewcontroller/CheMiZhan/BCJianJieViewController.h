//
//  BCJianJieViewController.h
//  carfun
//----------------------------------
//BC避震简介
//----------------------------------
//  Created by Piosa on 14-4-3.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "ParentViewViewController.h"

@interface BCJianJieViewController : ParentViewViewController

@end
