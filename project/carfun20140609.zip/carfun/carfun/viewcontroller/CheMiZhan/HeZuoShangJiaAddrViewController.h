//
//  HeZuoShangJiaAddrViewController.h
//  carfun
//----------------------------------
//    合作商家地址
//----------------------------------
//  Created by Piosa on 14-4-3.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "ParentViewViewController.h"

@interface HeZuoShangJiaAddrViewController : ParentViewViewController

@end
