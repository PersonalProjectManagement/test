//
//  SRrcerDetailViewController.m
//  carfun
//
//  Created by Piosa on 14-4-3.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "SRrcerDetailViewController.h"



@interface SRrcerDetailViewController ()

@end

@implementation SRrcerDetailViewController
@synthesize scrollView;
@synthesize scrollH;
@synthesize moveScale;
@synthesize detailFrame;
@synthesize productImgFrame;
@synthesize productImgView;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

-(void)loadView
{
    [super loadView];
    
    float x=0;
    float y=0;
    float w=ScreenHeight ;
    float h=ScreenWidth;
    
    //滚动视图
    scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(x, y, w, h)];
    scrollView.scrollEnabled=YES;
    scrollView.pagingEnabled=YES;
    [self.view addSubview:scrollView];
    
    //第一部分
    UIImageView *firstpart=[self getImageView:CGRectMake(x, y, w, h) withBg:@"detail_bg.png"];
    firstpart.userInteractionEnabled=YES;
    //左面滚动文本
    
    NSString *jieshaoTxt=@"   新华网北京4月7日电  2014中国－东盟文化交流年开幕式4月7日在北京举行。国务院总理李克强发来贺信。李克强对交流年开幕表示祝贺，并祝愿交流年圆满成功。李克强指出，中国和东盟山水相连、文化交融、血脉相亲。在漫长的历史进程中，双方人民创造了丰富多彩、享誉世界的灿烂文明，形成了具有区域特色的多元文化，成为各国生生不息、持续发展的精神支撑和丰厚滋养。文化搭建了沟通的桥梁，打开了心灵的窗户，增进了人民之间的相互了解和友谊，也为中国与东盟关系发展发挥了积极而独特的作用。李克强表示，今年是中国和东盟战略伙伴关系第二个十年的开局之年，中国和东盟关系正站在新的历史起点上。中国政府高度重视与东盟之间的睦邻友好与互利合作，希望通过本次文化交流年，向世界展示中国和东盟人文交往的丰硕果实，呈现双方文化艺术发展的辉煌成就，为中国和东盟各国艺术家和各国人民友好合作搭建更加广阔的舞台。李克强表示，中方愿同东盟方携手努力，保持中国－东盟友谊之树常青，共同谱写双方关系发展的崭新篇章，共同建设更加紧密的中国－东盟命运共同体，为亚洲及世界和平与发展做出更大贡献。东盟轮值主席国缅甸总统吴登盛、中国－东盟关系协调国泰国总理英拉也向开幕式发来贺信。新华网北京4月7日电  2014中国－东盟文化交流年开幕式4月7日在北京举行。国务院总理李克强发来贺信。李克强对交流年开幕表示祝贺，并祝愿交流年圆满成功。李克强指出，中国和东盟山水相连、文化交融、血脉相亲。在漫长的历史进程中，双方人民创造了丰富多彩、享誉世界的灿烂文明，形成了具有区域特色的多元文化，成为各国生生不息、持续发展的精神支撑和丰厚滋养。文化搭建了沟通的桥梁，打开了心灵的窗户，增进了人民之间的相互了解和友谊，也为中国与东盟关系发展发挥了积极而独特的作用。李克强表示，今年是中国和东盟战略伙伴关系第二个十年的开局之年，中国和东盟关系正站在新的历史起点上。中国政府高度重视与东盟之间的睦邻友好与互利合作，希望通过本次文化交流年，向世界展示中国和东盟人文交往的丰硕果实，呈现双方文化艺术发展的辉煌成就，为中国和东盟各国艺术家和各国人民友好合作搭建更加广阔的舞台。李克强表示，中方愿同东盟方携手努力，保持中国－东盟友谊之树常青，共同谱写双方关系发展的崭新篇章，共同建设更加紧密的中国－东盟命运共同体，为亚洲及世界和平与发展做出更大贡献。东盟轮值主席国缅甸总统吴登盛、中国－东盟关系协调国泰国总理英拉也向开幕式发来贺信。";
    UIFont *font=[UIFont systemFontOfSize:16];
    
    
    float lblX=50;
  
    float lblW=130;
    float lblY=30;
    
    float lblH =[CommonUtil getTxtHeight:jieshaoTxt forContentWidth:lblW fotFontSize:16];
    
    
    //介绍文本滚动视图
    scrollH=h-100;
    UIScrollView *jieshoScrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(lblX,lblY, lblW, scrollH)];
    jieshoScrollView.scrollEnabled=YES;
    jieshoScrollView.showsVerticalScrollIndicator=NO;
    jieshoScrollView.contentSize=CGSizeMake(lblW, lblH);
    jieshoScrollView.backgroundColor=[UIColor clearColor];
    jieshoScrollView.delegate=self;
    
    detailFrame=CGRectMake(0, 0, lblW, lblH);
    UILabel *detailLbl=[[UILabel alloc]initWithFrame:detailFrame];
    detailLbl.numberOfLines=0;
    detailLbl.font=font;
    detailLbl.backgroundColor=[UIColor clearColor];
    detailLbl.text=jieshaoTxt;
    
    [jieshoScrollView addSubview:detailLbl];
    
    [firstpart addSubview:jieshoScrollView];
    
    float paddingLeft=50;
    
    moveScale=paddingLeft/(lblH-scrollH);
    
    //产品图片
    float productImgX=lblX+lblW;
    productImgFrame=CGRectMake(productImgX, 70, (ScreenHeight-productImgX), 210);
    productImgView=[self getImageView:productImgFrame withBg:@"sc.png"];
    productImgView.backgroundColor=[UIColor clearColor];
    [firstpart addSubview:productImgView];
    [scrollView addSubview:firstpart];
 
    y+=h;
    
    //第二部分
    [scrollView addSubview:[self getImageView:CGRectMake(x, y, w, h) withBg:@"srfill.png"]];
    
    y+=h;
    
    //第3部分
    [scrollView addSubview:[self getImageView:CGRectMake(x, y, w, h) withBg:@"srfill2.png"]];
    
     y+=h;
    
    //第4部分
    
    UIImageView  *fourthPart=[self getImageView:CGRectMake(x, y, w, h) withBg:@"detail_bg.png"];
    //横向滚动 SR刹车套件
    fourthPart.userInteractionEnabled=YES;
    
    float titley=20;
     float titleH=40;
    //标题
    UILabel *titleLbl=[[UILabel alloc]initWithFrame:CGRectMake(0, titley, w, titleH)];
    titleLbl.font=[UIFont systemFontOfSize:22];
    titleLbl.textAlignment=NSTextAlignmentCenter;
    titleLbl.text=@"SR刹车套件";
    [fourthPart addSubview:titleLbl];
    
    float tempY=titleH+titley+50;
    float tempH=h-tempY;
    
    paddingLeft=30;
    
    UIScrollView *sctjScrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(paddingLeft, tempY, (w-paddingLeft*2), tempH)];
    sctjScrollView.scrollEnabled=YES;
    sctjScrollView.pagingEnabled=YES;
    sctjScrollView.showsHorizontalScrollIndicator=NO;
    [fourthPart addSubview:sctjScrollView];
    sctjScrollView.backgroundColor=[UIColor clearColor];
    
    NSMutableDictionary *data1=[[NSMutableDictionary alloc]init];
    [data1 setObject:@"sc.png" forKey:IMAGE_KEY];
    [data1 setObject:@"RA" forKey:NAME_KEY];
    
    
    NSMutableDictionary *data2=[[NSMutableDictionary alloc]init];
    [data2 setObject:@"sc.png" forKey:IMAGE_KEY];
    [data2 setObject:@"RB" forKey:NAME_KEY];
    
    
    
    NSMutableDictionary *data3=[[NSMutableDictionary alloc]init];
    [data3 setObject:@"sc.png" forKey:IMAGE_KEY];
    [data3 setObject:@"RC" forKey:NAME_KEY];
    
    
    NSMutableDictionary *data4=[[NSMutableDictionary alloc]init];
    [data4 setObject:@"sc.png" forKey:IMAGE_KEY];
    [data4 setObject:@"RD" forKey:NAME_KEY];
    
    NSArray *productList=@[data1,data2,data3,data4];
    
    float tempx=0;
    float tempw=(CGRectGetWidth(sctjScrollView.frame)/2);
    
    for (int i=0; i<productList.count; i++)
    {
        CGRect frame=CGRectMake(tempx, 0, tempw, tempH);
        UIView *v=[self getShaCheTaoJianItem:frame withDataItem:productList[i]];
        
        [sctjScrollView addSubview:v];
        
        tempx+=tempw;
    }
    
    sctjScrollView.contentSize=CGSizeMake(tempx, tempH);
    
    
    
    [scrollView addSubview:fourthPart];
    
    
    y+=h;
   
    scrollView.contentSize=CGSizeMake(w, y);
}

//得到一个刹车套件项
-(UIButton *)getShaCheTaoJianItem:(CGRect)frame withDataItem:(NSDictionary *)dataItem
{
    UIButton *item=[[UIButton alloc]initWithFrame:frame];

    
    //产品图片
    float w=CGRectGetWidth(frame);
    //float imgw=230;
    float imgh=150;
   // float imgx=(w-imgw)/2;
    UIImageView *imageView=[self getImageView:CGRectMake(0, 0, CGRectGetWidth(frame), imgh) withBg:[dataItem objectForKey:IMAGE_KEY]];
    
    [item addSubview:imageView];
    
    //产品名称
    UILabel *lbl=[[UILabel alloc]initWithFrame:CGRectMake(0, imgh+15, w, 20)];
    lbl.text=[dataItem objectForKey:NAME_KEY];
    lbl.textAlignment=NSTextAlignmentCenter;
    [item addSubview:lbl];
    lbl.backgroundColor=[UIColor clearColor];
    item.backgroundColor=[UIColor clearColor];
    
    
    return item;
}




- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    self.distinguishLbl.text=[NSString stringWithFormat:@"BC----产品类别----%@",self.param
            ];;
   // [self.view addSubview:self.distinguishLbl];
}

//产品介绍滚动视图滚动时图片左移
#pragma -mark 滚动视图代理

- (void)scrollViewDidScroll:(UIScrollView *)scrollViews
{
    float cy=scrollViews.contentOffset.y;
  
    
    productImgView.frame=CGRectMake(productImgFrame.origin.x-(cy*moveScale), productImgFrame.origin.y, CGRectGetWidth(productImgFrame), CGRectGetHeight(productImgFrame));
    

}




- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
