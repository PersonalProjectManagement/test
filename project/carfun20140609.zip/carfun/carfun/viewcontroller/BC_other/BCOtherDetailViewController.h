//
//  BCOtherDetailViewController.h
//  carfun
//
//  Created by Piosa on 14-4-3.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "ParentViewViewController.h"
#import "EffectView.h"
@interface BCOtherDetailViewController : ParentViewViewController
{
    EffectView *firstpart2;
    //第一页图片的结构
    CGRect imgframe;
    
    UIView *second;
    
    
    //控制滑动的方向
    float lastY;
    
    //记录是否切换到了第二页
    BOOL isToSecondPage;
    
  
}
@property(nonatomic,strong) NSString *param;


@end
