//
//  BCOtherDetailViewController.m
//  carfun
//
//  Created by Piosa on 14-4-3.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "BCOtherDetailViewController.h"

@interface BCOtherDetailViewController ()

@end


@implementation BCOtherDetailViewController
@synthesize scrollView;
@synthesize scrollH;
@synthesize moveScale;
@synthesize detailFrame;
@synthesize productImgFrame;
@synthesize productImgView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
  
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




-(void)loadView
{
    [super loadView];
    
    float x=0;
    float y=0;
    float w=ScreenHeight ;
    float h=ScreenWidth;
    
    //滚动视图
    scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(x, y, w, h)];
    scrollView.scrollEnabled=YES;
    scrollView.pagingEnabled=YES;
    scrollView.delegate=self;
    [self.view addSubview:scrollView];
    
    //第一部分
    UIImageView *firstpart=[self getImageView:CGRectMake(x, y, w, h) withBg:@"detail_bg.png"];
    firstpart.userInteractionEnabled=YES;
    //左面滚动文本
    
    NSString *jieshaoTxt=@"   新华网北京4月7日电  2014中国－东盟文化交流年开幕式4月7日在北京举行。国务院总理李克强发来贺信。李克强对交流年开幕表示祝贺，并祝愿交流年圆满成功。李克强指出，中国和东盟山水相连、文化交融、血脉相亲。在漫长的历史进程中，双方人民创造了丰富多彩、享誉世界的灿烂文明，形成了具有区域特色的多元文化，成为各国生生不息、持续发展的精神支撑和丰厚滋养。文化搭建了沟通的桥梁，打开了心灵的窗户，增进了人民之间的相互了解和友谊，也为中国与东盟关系发展发挥了积极而独特的作用。李克强表示，今年是中国和东盟战略伙伴关系第二个十年的开局之年，中国和东盟关系正站在新的历史起点上。中国政府高度重视与东盟之间的睦邻友好与互利合作，希望通过本次文化交流年，向世界展示中国和东盟人文交往的丰硕果实，呈现双方文化艺术发展的辉煌成就，为中国和东盟各国艺术家和各国人民友好合作搭建更加广阔的舞台。李克强表示，中方愿同东盟方携手努力";
    UIFont *font=[UIFont systemFontOfSize:16];
    
    
    float lblX=50;
    
    float lblW=130;
    float lblY=30;
    
    float lblH =[CommonUtil getTxtHeight:jieshaoTxt forContentWidth:lblW fotFontSize:16];
    
    
    //介绍文本滚动视图
    scrollH=h-100;
    UIScrollView *jieshoScrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(lblX,lblY, lblW, scrollH)];
    jieshoScrollView.scrollEnabled=YES;
    jieshoScrollView.showsVerticalScrollIndicator=NO;
    jieshoScrollView.contentSize=CGSizeMake(lblW, lblH);
    jieshoScrollView.backgroundColor=[UIColor clearColor];
    jieshoScrollView.delegate=self;
    
    detailFrame=CGRectMake(0, 0, lblW, lblH);
    UILabel *detailLbl=[[UILabel alloc]initWithFrame:detailFrame];
    detailLbl.numberOfLines=0;
    detailLbl.font=font;
    detailLbl.backgroundColor=[UIColor clearColor];
    detailLbl.text=jieshaoTxt;
    
    [jieshoScrollView addSubview:detailLbl];
    
    [firstpart addSubview:jieshoScrollView];
    
    float paddingLeft=80;
    
    moveScale=paddingLeft/(lblH-scrollH);
    
    //产品图片
    float productImgX=lblX+lblW+50;
    productImgFrame=CGRectMake(productImgX, 40,200, 250);
    productImgView=[self getImageView:productImgFrame withBg:@"biz.png"];//biz.png
    productImgView.tintAdjustmentMode=UIViewTintAdjustmentModeDimmed;
    productImgView.backgroundColor=[UIColor clearColor];
    [firstpart addSubview:productImgView];
    
    //产品图片
    float imgw=190;
    
    float imgh=270;
    
    float imgx=ScreenHeight-imgw-30;
    
    float imgy=30;
    
    
    
    
    firstpart2=[[EffectView alloc]initWithFrame:CGRectMake(x, y, w, h) withProductImgFrame:CGRectMake(imgx, imgy, imgw, imgh) withData:@[@"biz.png",jieshaoTxt]];
    
    
    [scrollView addSubview:firstpart2];
    
    y+=h;
    
    //第二部分
     second=[self getImageView:CGRectMake(x, y, w, h) withBg:@"dddad.png"];
    [scrollView addSubview:second];
    
    y+=h;
    
    //第3部分
    [scrollView addSubview:[self getImageView:CGRectMake(x, y, w, h) withBg:@"bb.png"]];
    
    y+=h;
    
    //第4部分
    
    UIImageView  *fourthPart=[self getImageView:CGRectMake(x, y, w, h) withBg:@"detail_bg.png"];
    //横向滚动 SR刹车套件
    fourthPart.userInteractionEnabled=YES;
    
    float titley=20;
    float titleH=40;
    //标题
    UILabel *titleLbl=[[UILabel alloc]initWithFrame:CGRectMake(0, titley, w, titleH)];
    titleLbl.font=[UIFont systemFontOfSize:22];
    titleLbl.textAlignment=NSTextAlignmentCenter;
    titleLbl.text=@"BR Design";
    [fourthPart addSubview:titleLbl];
    
    float tempY=titleH+titley+20;
    float tempH=h-tempY;
    
    paddingLeft=30;
    
    UIScrollView *sctjScrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, tempY, (w), tempH)];
    sctjScrollView.scrollEnabled=YES;
    sctjScrollView.pagingEnabled=YES;
    sctjScrollView.showsHorizontalScrollIndicator=NO;
    [fourthPart addSubview:sctjScrollView];
    sctjScrollView.backgroundColor=[UIColor clearColor];
    
    NSMutableDictionary *data1=[[NSMutableDictionary alloc]init];
    [data1 setObject:@"biz.png" forKey:IMAGE_KEY];
    [data1 setObject:@"RA" forKey:NAME_KEY];
    
    
    NSMutableDictionary *data2=[[NSMutableDictionary alloc]init];
    [data2 setObject:@"biz.png" forKey:IMAGE_KEY];
    [data2 setObject:@"RB" forKey:NAME_KEY];
    
    
    
    NSMutableDictionary *data3=[[NSMutableDictionary alloc]init];
    [data3 setObject:@"biz.png" forKey:IMAGE_KEY];
    [data3 setObject:@"RC" forKey:NAME_KEY];
    
    
    NSMutableDictionary *data4=[[NSMutableDictionary alloc]init];
    [data4 setObject:@"biz.png" forKey:IMAGE_KEY];
    [data4 setObject:@"RD" forKey:NAME_KEY];
    
    
    NSMutableDictionary *data5=[[NSMutableDictionary alloc]init];
    [data5 setObject:@"biz.png" forKey:IMAGE_KEY];
    [data5 setObject:@"RC" forKey:NAME_KEY];
    
    
    NSMutableDictionary *data6=[[NSMutableDictionary alloc]init];
    [data6 setObject:@"biz.png" forKey:IMAGE_KEY];
    [data6 setObject:@"RD" forKey:NAME_KEY];
    
    NSArray *productList=@[data1,data2,data3,data4,data5,data6];
    
    float tempx=0;
    float tempw=(CGRectGetWidth(sctjScrollView.frame)/3);
    
    for (int i=0; i<productList.count; i++)
    {
        CGRect frame=CGRectMake(tempx, 0, tempw, tempH);
        UIView *v=[self getShaCheTaoJianItem:frame withDataItem:productList[i]];
        
        [sctjScrollView addSubview:v];
        
        tempx+=tempw;
    }
    
    sctjScrollView.contentSize=CGSizeMake(tempx, tempH);
    
    
    
    [scrollView addSubview:fourthPart];
    
    
    y+=h;
    
    scrollView.contentSize=CGSizeMake(w, y);
}

//得到一个刹车套件项
-(UIButton *)getShaCheTaoJianItem:(CGRect)frame withDataItem:(NSDictionary *)dataItem
{
    UIButton *item=[[UIButton alloc]initWithFrame:frame];
    
    
    //产品图片
    float w=CGRectGetWidth(frame);
    //float imgw=230;
    float imgh=200;
    // float imgx=(w-imgw)/2;
    UIImageView *imageView=[self getImageView:CGRectMake(0, 0, CGRectGetWidth(frame), imgh) withBg:[dataItem objectForKey:IMAGE_KEY]];
    
    [item addSubview:imageView];
    
    //产品名称
    UILabel *lbl=[[UILabel alloc]initWithFrame:CGRectMake(0, imgh+5, w, 20)];
    lbl.text=[dataItem objectForKey:NAME_KEY];
    lbl.textAlignment=NSTextAlignmentCenter;
    [item addSubview:lbl];
    lbl.font=XILIE_FONT;
    lbl.backgroundColor=[UIColor clearColor];
    item.backgroundColor=[UIColor clearColor];
    
    
    return item;
}



//产品介绍滚动视图滚动时图片左移
#pragma -mark 滚动视图代理

- (void)scrollViewDidScroll:(UIScrollView *)scrollViews
{
    int cy=(int)scrollViews.contentOffset.y;
    
    NSLog(@"cy==%d  ScreenWidth=%f",cy,ScreenWidth);
    
    //第二页的图片从左向右出来
    UIView *img=[firstpart2 viewWithTag:IMG_TAG];
    
    //文本视图
    UIScrollView *txtContainer=[(UIScrollView *)firstpart2 viewWithTag:TXT_TAG];
    
    
    imgframe=img.frame;
    
    if (cy==0)
    {
        if (isToSecondPage)
        {
            isToSecondPage=NO;
            //  [firstpart2 setProductImgDefault];
        }
      
    }
    
    if (cy>0&&cy<ScreenWidth)
    {
//        
//        if (cy != lastY )
//        {
            [firstpart2 moveUp:cy];
            
           /**
            if (cy > lastY)
            {
            img.frame=CGRectMake(imgframe.origin.x-3, imgframe.origin.y, CGRectGetWidth(imgframe), CGRectGetHeight(imgframe));
            
            CGPoint point=txtContainer.contentOffset;
            
            txtContainer.contentOffset=CGPointMake(point.x, point.y+1);
            
            
            }else if(cy < lastY)
            {
            
            }

            */
          //  lastY = cy;
       // }
        
        
        
       
        
    }else if(cy==ScreenWidth)
    {
        img.frame=CGRectMake(0, imgframe.origin.y,CGRectGetWidth(imgframe), CGRectGetHeight(imgframe));
        
        isToSecondPage=YES;
        
    }
    
    
//    productImgView.frame=CGRectMake(productImgFrame.origin.x-(cy*moveScale), productImgFrame.origin.y, CGRectGetWidth(productImgFrame), CGRectGetHeight(productImgFrame));
    
    
    
    
}



@end
