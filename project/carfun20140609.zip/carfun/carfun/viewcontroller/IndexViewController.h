//
//  IndexViewController.h
//  carfun
//
//  Created by Piosa on 14-4-3.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ParentViewViewController.h"
//ParentViewViewController
#import "ShareView.h"
@interface IndexViewController : ParentViewViewController


@property(nonatomic,strong) UIImageView *background;
@end
