//
//  LunQuanCheZhaoViewController.m
//  carfun
//
//  Created by Piosa on 14-4-3.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "LunQuanCheZhaoViewController.h"

@interface LunQuanCheZhaoViewController ()

@end

@implementation LunQuanCheZhaoViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    MoreView *moreView=[[MoreView alloc]initWithFrame:CGRectMake(0, 0, ScreenHeight, ScreenWidth)];
    [self.view addSubview:moreView];
}


-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.rightMenu.hidden=NO;
    [self.rightMenu addTarget:self action:@selector(rightMenuEvent:) forControlEvents:UIControlEventTouchUpInside];
}


-(void)rightMenuEvent:(UIButton *)sender
{
    NSLog(@"------right Menu----");
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
