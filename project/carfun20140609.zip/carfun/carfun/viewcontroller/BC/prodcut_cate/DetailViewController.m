//
//  DetailViewController.m
//  carfun
//
//  Created by Piosa on 14-4-3.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "DetailViewController.h"

#define IMAGE_TAG 22

@interface DetailViewController ()

@end

@implementation DetailViewController
@synthesize scrollView;
@synthesize scrollH;
@synthesize moveScale;
@synthesize detailFrame;
@synthesize productImgFrame;
@synthesize productImgView;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    
    self.distinguishLbl.text=[NSString stringWithFormat:@"BC----产品类别----%@",self.detail_cate_name];;
    //[self.view addSubview:self.distinguishLbl];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.rightMenu.hidden=NO;
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(void)loadView
{
    [super loadView];
    
    float x=0;
    float y=0;
    float w=ScreenHeight ;
    float h=ScreenWidth;
    
    //滚动视图
    scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(x, y, w, h)];
    scrollView.scrollEnabled=YES;
    scrollView.pagingEnabled=YES;
    scrollView.delegate=self;
    
    [self.view addSubview:scrollView];
    
    //第一部分
   // UIImageView *firstpart=[self getImageView:CGRectMake(x, y, w, h) withBg:@"detail_bg.png"];
    //firstpart.userInteractionEnabled=YES;
    //左面滚动文本
    
    NSString *jieshaoTxt=@"   新华网北京4月7日电  2014中国－东盟文化交流年开幕式4月7日在北京举行。国务院总理李克强发来贺信。李克强对交流年开幕表示祝贺，并祝愿交流年圆满成功。";
    
    
   // UIImageView *firstpart=[self getScrollModalView:CGRectMake(x, y, w, h) withDetailTxt:jieshaoTxt withImg:@"bizb.png"];
    
  //  BCItem *firstpart=[[BCItem alloc]initWithFrame:CGRectMake(x, y, w, h)];
    
    NSMutableDictionary *itema=[[NSMutableDictionary alloc]init];
    [itema setObject:jieshaoTxt forKey:TXT_KEY];
    [itema setObject:@"bizb.png" forKey:IMG_KEY];
    
    //产品图片
    float imgw=220;
    
    float imgh=360;
    
    float imgx=ScreenHeight-imgw-30;
    
    float imgy=-30;
    
    firstpart=[[EffectView alloc]initWithFrame:CGRectMake(x, y, w, h) withProductImgFrame:CGRectMake(imgx, imgy, imgw, imgh)  withData:@[[itema objectForKey:IMG_KEY],[itema objectForKey:TXT_KEY]]];
    
 
    
    [scrollView addSubview:firstpart];
    
    y+=h;
    
   // UIImageView *part2ImgView=[self getScrollModalView:CGRectMake(x, y, w, h) withDetailTxt:jieshaoTxt withImg:@"bizs.png"];
    
    itema=[[NSMutableDictionary alloc]init];
    [itema setObject:jieshaoTxt forKey:TXT_KEY];
    [itema setObject:@"bizs.png" forKey:IMG_KEY];
    
    secondPart=[[EffectView alloc]initWithFrame:CGRectMake(x, y, w, h) withProductImgFrame:CGRectMake(imgx, imgy, imgw, imgh)   withData:@[[itema objectForKey:IMG_KEY],[itema objectForKey:TXT_KEY]]];

    
    //第二部分
    [scrollView addSubview:secondPart];
    
    y+=h;
    
    //第3部分
    UIImageView *threePartImgView=[self getImageView:CGRectMake(x, y, w, h) withBg:@"bc_car.png"];
    threePartImgView.userInteractionEnabled=YES;
    float btnW=60;
    float btnH=40;
    float btnX=w-btnW;
    float btnY=h-btnH;
    
    //更多按钮
    UIButton *moreBtn=[[UIButton alloc]initWithFrame:CGRectMake(btnX, btnY, btnW, btnH)];
    
    float seV=34.0/255.0;
    
    moreBtn.backgroundColor=[UIColor colorWithRed:seV green:seV blue:seV alpha:0.7];
    [moreBtn setTitle:@"更多" forState:UIControlStateNormal];
    [moreBtn setTitle:@"更多" forState:UIControlStateHighlighted];
    
    [moreBtn addTarget:self action:@selector(moreEvent:) forControlEvents:UIControlEventTouchUpInside];
    
    [threePartImgView addSubview:moreBtn];
    
    
    [scrollView addSubview:threePartImgView];
    
    y+=h;
    
    //第4部分
    
    UIImageView  *fourthPart=[self getImageView:CGRectMake(x, y, w, h) withBg:@"lqbj.png"];
    //横向滚动 SR刹车套件
    fourthPart.userInteractionEnabled=YES;
    
    float titley=20;
    float titleH=40;
    //标题
    UILabel *titleLbl=[[UILabel alloc]initWithFrame:CGRectMake(0, titley, w, titleH)];
    titleLbl.font=XILIE_FONT;
    titleLbl.textAlignment=NSTextAlignmentCenter;
    titleLbl.text=@"BS系列";
    titleLbl.backgroundColor=[UIColor clearColor];
    [fourthPart addSubview:titleLbl];
    
    float tempY=titleH+titley;
    float tempH=h-tempY;
    
    float paddingLeft=30;
    
    UIScrollView *sctjScrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(paddingLeft, tempY, (w-paddingLeft*2), tempH)];
    sctjScrollView.scrollEnabled=YES;
    sctjScrollView.pagingEnabled=YES;
    sctjScrollView.showsHorizontalScrollIndicator=NO;
    [fourthPart addSubview:sctjScrollView];
    sctjScrollView.backgroundColor=[UIColor clearColor];
    
    NSMutableDictionary *data1=[[NSMutableDictionary alloc]init];
    [data1 setObject:@"bizs.png" forKey:IMAGE_KEY];
    [data1 setObject:@"BSO1" forKey:NAME_KEY];
    
    
    NSMutableDictionary *data2=[[NSMutableDictionary alloc]init];
    [data2 setObject:@"bizs.png" forKey:IMAGE_KEY];
    [data2 setObject:@"BSO2" forKey:NAME_KEY];
    
    
    
    NSMutableDictionary *data3=[[NSMutableDictionary alloc]init];
    [data3 setObject:@"bizs.png" forKey:IMAGE_KEY];
    [data3 setObject:@"RC" forKey:NAME_KEY];
    
    
    NSMutableDictionary *data4=[[NSMutableDictionary alloc]init];
    [data4 setObject:@"bizs.png" forKey:IMAGE_KEY];
    [data4 setObject:@"RD" forKey:NAME_KEY];
    
    NSArray *productList=@[data1,data2,data3,data4];
    
    float tempx=0;
    float tempw=(CGRectGetWidth(sctjScrollView.frame)/2);
    
    for (int i=0; i<productList.count; i++)
    {
        CGRect frame=CGRectMake(tempx, 0, tempw, tempH);
        UIView *v=[self getShaCheTaoJianItem:frame withDataItem:productList[i] withIsRight:(i%2==0)];
        
        [sctjScrollView addSubview:v];
        
        tempx+=tempw;
    }
    
    sctjScrollView.contentSize=CGSizeMake(tempx, tempH);
    
    
    
    [scrollView addSubview:fourthPart];
    
    
    y+=h;
    
    NSLog(@"y==%f",y);
    
    scrollView.contentSize=CGSizeMake(w, y);
}

//更多点击事件
-(void)moreEvent:(UIButton *)sender
{
    NSLog(@"--more---");
    
    LunQuanCheZhaoViewController *vc=[[LunQuanCheZhaoViewController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
    
  /*
   float y=scrollView.contentSize.height;
   float w=CGRectGetWidth(scrollView.frame);
   float h=CGRectGetHeight(scrollView.frame);
   
   MoreView *moreView=[[MoreView alloc]initWithFrame:CGRectMake(0, y, w, h)];
   [scrollView addSubview:moreView];
   
   scrollView.contentSize=CGSizeMake(w, h+y);
   scrollView.contentOffset=CGPointMake(0, y);
   */
}




//得到一个刹车套件项
-(UIButton *)getShaCheTaoJianItem:(CGRect)frame withDataItem:(NSDictionary *)dataItem withIsRight:(BOOL)isRight
{
    UIButton *item=[[UIButton alloc]initWithFrame:frame];
    
    //项宽度
    float w=CGRectGetWidth(frame);
    
    //产品图片
    float imgw=170;
    
    float imgh=260;
    
     float imgx=0;
    
    if (isRight)
    {
        imgx=(w-imgw);
    }
    
    
    UIImageView *imageView=[self getImageView:CGRectMake(imgx, -50, imgw, imgh) withBg:[dataItem objectForKey:IMAGE_KEY]];
    
    [item addSubview:imageView];
    
    //产品名称
    UILabel *lbl=[[UILabel alloc]initWithFrame:CGRectMake(imgx, imgh-60, imgw, 20)];
    lbl.text=[dataItem objectForKey:NAME_KEY];
    lbl.textAlignment=NSTextAlignmentCenter;
    [item addSubview:lbl];
    lbl.font=XILIE_FONT;
    lbl.backgroundColor=[UIColor clearColor];
    item.backgroundColor=[UIColor clearColor];
    
    
    return item;
}


//根据传入的位置，图片，文字，返回一个文本和图片滚动的视图
-(UIImageView *)getScrollModalView:(CGRect)frame withDetailTxt:(NSString *)msg withImg:(NSString  *)imgName
{
    UIImageView  *fourthPart=[self getImageView:frame withBg:@"detail_bg.png"];
    //横向滚动 SR刹车套件
    fourthPart.userInteractionEnabled=YES;
    
    float lblX=50;
    
    float lblW=130;
    float lblY=30;
  
    float h=ScreenWidth;
    
    int fontSize=18;
    
    float lblH =[CommonUtil getTxtHeight:msg forContentWidth:lblW fotFontSize:fontSize];
    
    //介绍文本滚动视图
    float  lscrollH=h-100;
    UIScrollView *jieshoScrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(lblX,lblY, lblW, lscrollH)];
    jieshoScrollView.scrollEnabled=YES;
    jieshoScrollView.showsVerticalScrollIndicator=NO;
    jieshoScrollView.contentSize=CGSizeMake(lblW, lblH);
    jieshoScrollView.backgroundColor=[UIColor clearColor];
    jieshoScrollView.delegate=self;
    
    detailFrame=CGRectMake(0, 0, lblW, lblH);
    UILabel *detailLbl=[[UILabel alloc]initWithFrame:detailFrame];
    detailLbl.numberOfLines=0;
    detailLbl.font=[UIFont systemFontOfSize:fontSize];
    detailLbl.backgroundColor=[UIColor clearColor];
    detailLbl.text=msg;
    
    [jieshoScrollView addSubview:detailLbl];
    
    [fourthPart addSubview:jieshoScrollView];
    
    float paddingLeft=50;
    
    
    
    moveScale=(paddingLeft+20)/(lblH-lscrollH);
    
    //产品图片
    float productImgX=lblX+lblW+paddingLeft;
    
 
    
    productImgFrame=CGRectMake(productImgX, -30, 240, ScreenWidth+40);
    UIImageView *lproductImgView=[self getImageView:productImgFrame withBg:imgName];
    lproductImgView.backgroundColor=[UIColor clearColor];
    lproductImgView.tag=IMAGE_TAG;
    [fourthPart addSubview:lproductImgView];
   
    
    return fourthPart;

}


 
//产品介绍滚动视图滚动时图片左移
#pragma -mark 滚动视图代理

- (void)scrollViewDidScroll:(UIScrollView *)scrollViews
{
     int cy=(int)scrollViews.contentOffset.y;
    
    NSLog(@"main page=>%d",cy);
    
    if (cy==0)
    {
        isThirdReturn=NO;
        
        isSecondReturn=NO;
    }else if(cy==ScreenWidth)
    {
        //设置滚动视图文本的Y坐标偏移量为0，y坐标上移一段距离
        
        isSecondReturn=YES;
        
        isThirdReturn=NO;
        
    }else if(cy==ScreenWidth*2)
    {
        isThirdReturn=YES;
    }
    
    if ((isSecondReturn&&(cy>0&&cy<ScreenWidth)))
    {
        [firstpart moveDown:scrollViews.contentOffset.y];
        
        
    }else if ((isThirdReturn&&(cy>ScreenWidth&&cy<2*ScreenWidth)))
    {
        
             [secondPart moveDown:scrollViews.contentOffset.y];
        
    }else
    {
        if (cy>0&&cy<ScreenWidth)
        {
            [firstpart moveUp:cy];
            
            isSecondReturn=NO;
        }
        else if(cy>ScreenWidth&&cy<2*ScreenWidth)
        {
            [secondPart moveUp:cy-ScreenWidth];
            
            isSecondReturn=YES;
            
            isThirdReturn=NO;
            
        }else if(cy>ScreenWidth*2&&cy<3*ScreenWidth)
        {
            [secondPart moveUp:cy-ScreenWidth];
            
            isThirdReturn=YES;
        }

    }
    
    
    
    
    
}




@end
