//
//  BCItem.m
//  carfun
//
//  Created by Piosa on 14-5-22.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "BCItem.h"

@implementation BCItem

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self initDefData];
        
        [self initView];
        
    }
    return self;
}


-(void)initView
{
    container=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, ScreenHeight, ScreenWidth)];
    container.scrollEnabled=YES;
    container.pagingEnabled=YES;
    [self addSubview:container];
    
    float x=0;
    
    for (int i=0; i<items.count; i++)
    {
        x=i*ScreenHeight;
        
        NSDictionary *item=items[i];
        
        // EffectView *effectView=[[EffectView alloc]initWithFrame:CGRectMake(x, 0, ScreenHeight, ScreenWidth) withData:@[[item objectForKey:IMG_KEY],[item objectForKey:TXT_KEY]]];
        
      //  [container addSubview:effectView];
    }
    
    container.contentSize=CGSizeMake(items.count*ScreenHeight, ScreenWidth);
    container.showsHorizontalScrollIndicator=NO;
    
}

-(void)initDefData
{
    NSString *jieshaoTxt=@"   新华网北京4月7日电  2014中国－东盟文化交流年开幕式4月7日在北京举行。国务院总理李克强发来贺信。李克强对交流年开幕表示祝贺，并祝愿交流年圆满成功。李克强指出，中国和东盟山水相连、文化交融、血脉相亲。在漫长的历史进程中，双方人民创造了丰富多彩、享誉世界的灿烂文明，形成了具有区域特色的多元文化，成为各国生生不息、持续发展的精神支撑和丰厚滋养。文化搭建了沟通的桥梁，打开了心灵的窗户，增进了人民之间的相互了解和友谊，也为中国与东盟关系发展发挥了积极而独特的作用。李克强表示，今年是中国和东盟战略伙伴关系第二个十年的开局之年，中国和东盟关系正站在新的历史起点上。中国政府高度重视与东盟之间的睦邻友好与互利合作，希望通过本次文化交流年，向世界展示中国和东盟人文交往的丰硕果实，呈现双方文化艺术发展的辉煌成就，为中国和东盟各国艺术家和各国人民友好合作搭建更加广阔的舞台。李克强表示，中方愿同东盟方携手努力";
    
    NSMutableDictionary *itema=[[NSMutableDictionary alloc]init];
    [itema setObject:jieshaoTxt forKey:TXT_KEY];
    [itema setObject:@"bizb.png" forKey:IMG_KEY];
    
    NSMutableDictionary *itemb=[[NSMutableDictionary alloc]init];
    [itemb setObject:jieshaoTxt forKey:TXT_KEY];
    [itemb setObject:@"bizs.png" forKey:IMG_KEY];
    
    
    items=@[itema,itemb];
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
