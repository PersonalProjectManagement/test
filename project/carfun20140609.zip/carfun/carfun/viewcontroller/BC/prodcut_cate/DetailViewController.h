//
//  DetailViewController.h
//  carfun
// *firstpart
//  Created by Piosa on 14-4-3.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "ParentViewViewController.h"
#import "CommonUtil.h"
#import "MoreView.h"
#import "LunQuanCheZhaoViewController.h"
#import "EffectView.h"
#import "BCItem.h"
@interface DetailViewController : ParentViewViewController<UIScrollViewDelegate>
{
    CommonUtil *commontUtil;
    
    EffectView *firstpart;
    
    EffectView *secondPart;
    
    BOOL isSecondReturn;
    
    BOOL isThirdReturn;
    
    
}

@property(nonatomic,strong)  NSString *detail_cate_name;

@end
