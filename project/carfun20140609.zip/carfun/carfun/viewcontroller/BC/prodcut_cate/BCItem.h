//
//  BCItem.h
//  carfun
//
//  Created by Piosa on 14-5-22.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EffectView.h"

#define TXT_KEY  @"TXT_KEY"

#define IMG_KEY  @"IMG_KEY"


@interface BCItem : UIView
{
    NSArray *items;
    
    UIScrollView *container;
}
@end
