//
//  MoreView.h
//  carfun
//
//  Created by Piosa on 14-4-10.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonUtil.h"

//--------------------------------------
//------产品列表的事件代理-----------------
//--------------------------------------
@protocol ProductListDelegate <NSObject>

//当点击产品项的时候
-(void)onItemClick:(NSDictionary *)itemData;

@end


//----------------------------
//-----更多视图
//---------------------------

@interface MoreView : UIView
{
    CommonUtil *commontUtil;
    
    //更多中产品滚动视图
    UIScrollView *scrollView;
    
    float w;
    
} 

@property id<ProductListDelegate> delegate;


@property(nonatomic,strong) NSMutableArray *dataList;
@end

