//
//  MoreView.m
//  carfun
//
//  Created by Piosa on 14-4-10.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "MoreView.h"

@implementation MoreView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        commontUtil=[[CommonUtil alloc]init];
        self.dataList=[[NSMutableArray alloc]initWithArray:@[@"bc_car.png",@"bc_car.png",@"bc_car.png",@"bc_car.png",@"bc_car.png",@"bc_car.png",@"bc_car.png",@"bc_car.png",@"bc_car.png",@"bc_car.png"]];
        
        
        [self initView];
        
    }
    return self;
}


-(void)initView
{
      w=CGRectGetWidth(self.frame);
    float h=CGRectGetHeight(self.frame);
    
    //品牌和车型栏
    float  W=w;
    float  H=40;
    float  X=0;
    float  Y=0;
    
    UIView *branBar=[[UIView alloc]initWithFrame:CGRectMake(X, Y, W, H)];
    branBar.backgroundColor=[UIColor clearColor];
    
    
    
    
    //产品列表视图
    scrollView=[[UIScrollView alloc]initWithFrame:CGRectMake(0, H, w, h-H)];
    
    scrollView.scrollEnabled=YES;
    scrollView.showsVerticalScrollIndicator=NO;
    scrollView.backgroundColor=[UIColor clearColor];
    [self addSubview:scrollView];
    
    [self addSubview:branBar];
    
    float half=(w/2);
    float btnw=130;
    float btnh=30;
    float btny=(H-btnh)/2;
    float btnx=(half-btnw)/2;
    
    CGRect frame=CGRectMake(btnx, btny, btnw, btnh);
    
    [branBar addSubview:[self getSelectBtn:frame withTitle:@"品牌" withTag:1]];
    
    
    frame=CGRectMake(half+btnx, btny, btnw, btnh);
    
    [branBar addSubview:[self getSelectBtn:frame withTitle:@"车型" withTag:2]];

    
    
    [self initProductListView];
}

//初始化产品列表视图

-(void)initProductListView
{
    float padding=10;
    
    float itemW=(w-padding*3)/2;
    
    float itemH=140;
    
    float itemY=padding;
    
    float itemX=padding;
    
    for (int i=0; i<self.dataList.count; i++)
    {
        if (i%2==0)
        {
             itemX=padding;
            
            if (i==0)
            {
                itemY=padding;
            }else
            {
                itemY+=(padding+itemH);
            }
            
        }else
        {
            itemX+=(padding+itemW);
        }
        
        CGRect itemFrame=CGRectMake(itemX, itemY, itemW, itemH);
        
        UIButton *itemBtn=[self getItem:itemFrame withImgName:self.dataList[i] withTag:i];
        [scrollView addSubview:itemBtn];
    }
    
    scrollView.contentSize=CGSizeMake(w,itemY+itemH);

}


//得到一个品牌和车型下拉选项按钮
-(UIButton *)getSelectBtn:(CGRect)frame withTitle:(NSString *)title withTag:(int)tag
{
    UIButton *btn=[[UIButton alloc]initWithFrame:frame];
    [btn setBackgroundImage:[UIImage imageNamed:@"xuanz.png"] forState:UIControlStateHighlighted];
     [btn setBackgroundImage:[UIImage imageNamed:@"xuanz.png"] forState:UIControlStateNormal];
    btn.backgroundColor=[UIColor greenColor];
    
    float lblw=CGRectGetWidth(frame)-15;
    UILabel *lbl=[[UILabel alloc]initWithFrame:CGRectMake(0, 0, lblw, CGRectGetHeight(frame))];
    lbl.backgroundColor=[UIColor clearColor];
    lbl.text=title;
    lbl.textAlignment=NSTextAlignmentCenter;
    lbl.font=[UIFont systemFontOfSize:14];
    [btn addSubview:lbl];
    btn.tag=tag;
    [btn addTarget:self action:@selector(itemClick:) forControlEvents:UIControlEventTouchUpInside];
    
    
    return btn;
}

-(void)itemClick:(UIButton *)sender
{
    NSLog(@"--->");
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/


//得到一个图片按钮项
-(UIButton *)getItem:(CGRect)frame withImgName:(NSString *)imgName withTag:(int)tag
{
    UIButton *btnIte=[[UIButton alloc]initWithFrame:frame];
    [commontUtil setBg:btnIte withImgName:imgName];
    btnIte.tag=tag;
    [btnIte addTarget:self action:@selector(clickItemEvent:) forControlEvents:UIControlEventTouchUpInside];
    
    return btnIte;
}

-(void)clickItemEvent:(UIButton *)sender
{
    if (self.delegate)
    {
        NSMutableDictionary *item=[[NSMutableDictionary alloc]init];
        [item setObject:@"test" forKey:@"key"];
    
    
         [self.delegate onItemClick:item];
    }
   
}


@end
