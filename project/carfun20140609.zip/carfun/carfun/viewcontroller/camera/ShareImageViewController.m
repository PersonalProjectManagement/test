//
//  ShareImageViewController.m
//  carfun
//
//  Created by Piosa on 14-5-29.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "ShareImageViewController.h"
#import "ShareView.h"
#import "CarFanCustomImagePickerControllerViewController.h"
//分享选择按钮的Tag
#define SHARE_BTN_TAG  88
@interface ShareImageViewController ()

@end

@implementation ShareImageViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//    self.imageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
//    self.imageView.image=self.image;
//    [self.view addSubview:self.imageView];
    
    
//    ShareView *share=[[ShareView alloc]initWithFrame:self.view.frame];
//    share.transform=CGAffineTransformRotate(CGAffineTransformIdentity,270*(M_PI/180));
//    share.shareImageView.image=self.image;
//    
//    [self.view addSubview:share];
    
   
    
    //距离上面的距离
      pt=10;
    
    //设置分享方式
    shareList=@[@"腾讯微博",@"新浪微博",@"QQ空间",@"人人网"];
    
    //设置背景颜色
     float sz=54.0/255.0;
    self.view.backgroundColor=[UIColor colorWithRed:sz green:sz blue:sz alpha:1.0];
    
    //下划线颜色
    sz=28.0/255.0;
    
    lineColor=[UIColor colorWithRed:sz green:sz blue:sz alpha:1.0];
    
    [self initLeftPartView];
    
    [self initRightPartView];
    
  
    
    //关闭按钮
    float closeBtnw=pt;
    float x=ScreenHeight-closeBtnw;
    float y=0;
    self.closeBtn=[[UIButton alloc]initWithFrame:CGRectMake(x, y, closeBtnw, closeBtnw)];
    [CommonUtil setBgOnBtn:self.closeBtn withImage:@[@"closeBtnBg.png",@"closeBtnBg.png"]];
    [self.closeBtn addTarget:self action:@selector(exit:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.closeBtn];

    
}



//初始化创建左部分视图
-(void)initLeftPartView
{
    float h=(ScreenHeight/9)*5;
    float btnw=42;
    float btnh=38;
    
    leftPartView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, h, ScreenWidth)];
    
    
    leftPartView.backgroundColor=[UIColor clearColor];
    [self.view addSubview:leftPartView];
    
    
    //返回按钮
    self.backBtn=[[UIButton alloc]initWithFrame:CGRectMake(0, ScreenWidth-btnh, btnw, btnh)];
    [self.backBtn addTarget:self action:@selector(backToTakePhoto:) forControlEvents:UIControlEventTouchUpInside];
    [CommonUtil setBgOnBtn:self.backBtn withImage:@[@"fanhuinomal.png",@"fanhuinomal.png"]];
    
    
    //分享图片
    
    
    float w=h-60;
    float imgh=ScreenWidth/2-30;
    float x=20;
    float y=(ScreenWidth-imgh)/2;
    
    self.shareImageView=[[UIImageView alloc]initWithFrame:CGRectMake(x, y, w, imgh)];
    self.shareImageView.backgroundColor=[UIColor blueColor];
    self.shareImageView.transform=CGAffineTransformRotate(CGAffineTransformIdentity, -7*(M_PI/180));;
    self.shareImageView.image=self.image;
    [leftPartView addSubview:self.shareImageView];
    
    [leftPartView addSubview:self.backBtn];
    
}

#define itemH 40


//初始化右部分
-(void)initRightPartView
{
    
    float y=0;
    float x=CGRectGetWidth(leftPartView.frame);
    float w=ScreenHeight-x-pt;
    
    rightPartView=[[UIView alloc]initWithFrame:CGRectMake(x, y, w,ScreenWidth )];
    rightPartView.backgroundColor=[UIColor clearColor];
    
    [self.view addSubview:rightPartView];
    
     x=0;
    y=pt;
    float h=itemH*4;
    
    float sz=31.0/255.0;
    
    UIColor *borderColor=[UIColor colorWithRed:sz green:sz blue:sz alpha:1.0];
    
    //分享模块容器
    shareViewContainer=[[UIView alloc]initWithFrame:CGRectMake(x, y, w, h)];
    shareViewContainer.layer.borderColor=[borderColor CGColor];
    shareViewContainer.layer.borderWidth=2;
    shareViewContainer.layer.cornerRadius=2;
    
    sz=44.0/255.0;
    
    shareViewContainer.backgroundColor=[UIColor colorWithRed:sz green:sz blue:sz alpha:1.0];
    
    
    
    
    
    float itemY=0;
    for (int i=0; i<shareList.count; i++)
    {
        CGRect frame=CGRectMake(0, itemY, w, itemH);
        UIView *item=[self getShareItem:frame withTitle:shareList[i] withTag:i];
        item.tag=i;
        [shareViewContainer addSubview:item];
        
        itemY+=itemH;
    }

    
    
    
    [rightPartView addSubview:shareViewContainer];
    
    y+=h+pt;
    h=ScreenWidth-5*itemH-4*pt;
    //分享内容 CGRectMake(x, y, w, h)
    self.shareContentView=[[UITextView alloc]initWithFrame:CGRectMake(x, y, w, h)];
    self.shareContentView.backgroundColor=[UIColor whiteColor];
    
    self.shareContentView.layer.borderWidth=1;
    self.shareContentView.layer.cornerRadius=3;
    [rightPartView addSubview:self.shareContentView];
    
    //发送分享内容按钮
    
    y=ScreenWidth-itemH-pt;
    self.sendShareBtn=[[UIButton alloc]initWithFrame:CGRectMake(x, y, w, itemH)];
    self.sendShareBtn.backgroundColor=[UIColor clearColor];
    [self.sendShareBtn addTarget:self action:@selector(sendShareEvent:) forControlEvents:UIControlEventTouchUpInside];
    [CommonUtil setBgOnBtn:self.sendShareBtn withImage:@[@"sendShareBtnImg.png",@"sendShareBtnImg.png"]];
    
    [rightPartView addSubview:self.sendShareBtn];
    
    
}

//该方法得到分享项
-(UIView *)getShareItem:(CGRect)frame withTitle:(NSString *)title withTag:(int)tag
{
    UIView *view=[[UIView alloc]initWithFrame:frame];
 
    float itemHeight=CGRectGetHeight(frame);
    //标题
    UILabel *lbl=[[UILabel alloc]initWithFrame:CGRectMake(15, 0, 100, itemHeight)];
    lbl.text=title;
    lbl.textColor=[UIColor whiteColor];
    lbl.backgroundColor=[UIColor clearColor];
    
    [view addSubview:lbl];
    
    //是否分享的切换
    float w=65;
    float h=26;
    float x=CGRectGetWidth(frame)-w-10;
    float y=(itemHeight-h)/2;
    UIButton *shareSwitch=[[UIButton alloc]initWithFrame:CGRectMake(x, y, w, h)];
    shareSwitch.selected=NO;
    shareSwitch.tag=SHARE_BTN_TAG;
    [shareSwitch addTarget:self action:@selector(btnStateChange:) forControlEvents:UIControlEventTouchUpInside];
   // [shareSwitch addTarget:self action:@selector(btnStateChange:) forControlEvents:UIControlEventTouchDragInside];
    [shareSwitch setBackgroundImage:[UIImage imageNamed:@"guan.png"] forState:UIControlStateSelected];
    [shareSwitch setBackgroundImage:[UIImage imageNamed:@"guan.png"] forState:UIControlStateNormal];
    [view addSubview:shareSwitch];
    
    //下划线
  
    
    float lineH=2;
    
    UIView *lineView=[CommonUtil getLine:CGRectMake(0, itemHeight-lineH, CGRectGetWidth(frame), lineH) withLineColor:lineColor];
    lineView.layer.shadowOffset=CGSizeMake(2, 2);
    
    [view addSubview:lineView];

    
    return view;

}

//当点击发送，进行分享事件
-(void)sendShareEvent:(UIButton *)sender
{
    NSMutableArray *canShareList=[[NSMutableArray alloc] init];
    for (int i=0; i<shareList.count; i++)
    {
        UIButton *btn=(UIButton *)[[shareViewContainer viewWithTag:i] viewWithTag:SHARE_BTN_TAG];
        
        if (btn.selected)
        {
            [canShareList addObject:shareList[i]];
        }
        
    }
    
    NSLog(@"canShareList=%@",canShareList.description);
}


//切换分享状态
-(void)btnStateChange:(UIButton *)sender
{
    NSString *stateImgName;
    if (sender.selected)
    {
        stateImgName=@"guan.png";
        sender.selected=NO;
    }else
    {
         stateImgName=@"kai.png";
        sender.selected=YES;
    }
    
    [sender setBackgroundImage:[UIImage imageNamed:stateImgName] forState:UIControlStateSelected];
    [sender setBackgroundImage:[UIImage imageNamed:stateImgName] forState:UIControlStateNormal];

}

-(void)backToTakePhoto:(UIButton *)sender
{
    CarFanCustomImagePickerControllerViewController *vc=[[CarFanCustomImagePickerControllerViewController alloc] init];
    vc.imageAfterTake=self.imageAfterTake;
     vc.uiViewController=self;
    vc.externalNavgation=self.navigationController;
    
    vc.currentSelectedWheelIndex=self.currentSelectedWheelIndex;
    [super pushToTakePhoto:vc];
}


//点击x退出
-(void)exit:(UIButton *)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
