//
//  CustomImagePickerController.h
//  MeiJiaLove
//
//  Created by Wu.weibin on 13-7-9.
//  Copyright (c) 2013年 Wu.weibin. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UIImage+fixOrientation.h"

#import "ShareView.h"

#import "CommonUtil.h"
#import "UIImagePickerController+MyUIImagePickerController.h"

@protocol CarFanCustomImagePickerControllerDelegate;

@interface CarFanCustomImagePickerControllerViewController : UIImagePickerController
<UINavigationControllerDelegate,UIImagePickerControllerDelegate>
{ 
    CommonUtil *commonUtil;
    UIImage *imagein;
    
    UIView *PLCameraView;
    
    UIImageView *container;
    
    UIView *PLVideoPreviewView;
    
    //车模型
    UIImageView *carModal;
    
    //车模型的尺寸
    CGRect carFrame;
    
    //轮子
    UIImageView *wheel_front,*wheel_behind;
    
    UIButton *wheelFront;
    
    NSArray *wheels;
    
    
    float scaelSize;
    
    CGPoint centerPoint,wf_center,wb_center;
    
    //轮子的减小比例
    float scale;
    
    float w_scale;
    
    
    //默认的轮子中心点便于纠正
    CGPoint df_center,db_center;
    
    //默认车站的宽高
    float cw;
    float ch;
    
    
    //图层视图 包括菜单，返回，ok，旋转轮圈放大缩小等按钮
   // UIView *overlayView;
    
    //该图层包括用户设置的轮子
    UIView *overlayWatermark;
    
    //左菜单按钮
    UIButton *leftMenuBtn;
    
    //返回按钮
    UIButton *backBtn;
    
    //ok按钮
    UIButton *okBtn;
    
    //放大按钮
    UIButton *zoomInBtn;
    
    //缩小按钮
    UIButton *zoomOutBtn;
    
    //大图缩放
    UIButton *seeBigViewBtn;
    
    //底部栏
    UIView *bottomColumnView;
    
    //照相后的图片
    UIImageView *imageView;
    
    //改变量记录是pop还是把当前显示的视图隐藏掉
    BOOL ispop;
    
    //该变量记录ok按钮是拍照还是去分享页面
    BOOL alreadyTaked;
    
    //上部背景视图
    UIImageView *topView;
    
    //底部背景视图
    UIImageView *bottomView;
    
    //底部轮圈视图
    UIView *bottomLunQuanView;
    
    //轮圈实物图片显示视图
    UIImageView *wheelEntityView;
    
    //轮子宽度
    float wheelDiameter;
    
    //设置车上轮子的拖动事件
    UIPanGestureRecognizer *panGestureRecognizerFrontWheel;//前轮
    
    
    UIPanGestureRecognizer *panGestureRecognizerBehindWheel;//后轮
    
   
    //当前选择的车轮图片
    UIImage *currentSelectedWheelImage;
    
    //当前选择的车轮
    UIButton *currentSelectedWheelBtn;
    
    
    //前轮后轮的默认中心点
    CGPoint defaultFrontWheelPoint;
    
    CGPoint defaultBackWheelPoint;
    
    //该变量为和成后的图片
    UIImage *finallyImage;
    
    //该变量判断是分享返回还是直接进入的
    BOOL isShareBack;
    
    //---------------------------------------------------------------------------------
    //---左菜单---------------------------------------------------------
    //---------------------------------------------------------------------------------
    
    UIView *firstGradeMenu;
    
    UIView *secondGradeMenu;
    
    UIView *thirdGradeMenu;
    
    UIView *menuContainer;
    
    CGRect leftFrame;
    
    
    //视图第一次到第三层
    ItemView *layerOne;
    
    ItemView *layerTwo;
    
    ItemView *layerThree;
    
    
    
    //第一级视图的Frame
    CGRect first_grade_frame;
    
    CGRect default_second_grade_frame;
    
    CGRect default_three_grade_frame;
    
    
    
    //默认的列表位置
    CGRect defaultFrame;
    
    //第二层的默认框架尺寸
    CGRect  secondDefaultFrame;
    
    

}

//照相后得到的图片
@property(nonatomic,strong) UIImage *imageAfterTake;

//记录选择轮子的索引
@property int currentSelectedWheelIndex;

@property(nonatomic,strong) UIViewController *uiViewController;

@property(nonatomic,assign) UINavigationController *externalNavgation;


-(void)showLeftMenuBtn;

//@property(nonatomic,assign)id<CarFanCustomImagePickerControllerDelegate> customDelegate;
@end

@protocol CarFanCustomImagePickerControllerDelegate <NSObject>

- (void)cameraPhoto:(UIImage *)image;

@end
