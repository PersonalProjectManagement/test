//
//  CustomImagePickerController.h
//  MeiJiaLove
//
//  Created by Wu.weibin on 13-7-9.
//  Copyright (c) 2013年 Wu.weibin. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "UIImage+fixOrientation.h"


@protocol CustomImagePickerControllerDelegate;

@interface CustomImagePickerController : UIImagePickerController
<UINavigationControllerDelegate,UIImagePickerControllerDelegate>
{
    id<CustomImagePickerControllerDelegate> _customDelegate;
    
    UIImage *imagein;
    
    UIView *PLCameraView;
    
    UIImageView *container;
    
    UIView *PLVideoPreviewView;
    
    //车模型
    UIImageView *carModal;
    
    //轮子
    UIImageView *wheel_font,*wheel_behind;
    
    NSArray *wheels;
    
 
    float scaelSize;
    
    CGPoint centerPoint,wf_center,wb_center;
    
    //轮子的减小比例
    float scale;
    
    float w_scale;
    
    
    //默认的轮子中心点便于纠正
    CGPoint df_center,db_center;
    
    //默认车站的宽高
    float cw;
    float ch;
    
}




@property(nonatomic)BOOL isSingle;
@property(nonatomic,assign)id<CustomImagePickerControllerDelegate> customDelegate;
@end

@protocol CustomImagePickerControllerDelegate <NSObject>

- (void)cameraPhoto:(UIImage *)image withShuiYing:(UIImage *)imageShuiYin;
- (void)cancelCamera;
@end
