
//
//  ShareView.m
//  carfun
//
//  Created by Piosa on 14-5-28.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "ShareView.h"
//--------------------------------------------------
//---分享视图-----------------------------
//--------------------------------------------------
@implementation ShareView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        commonUtil=[[CommonUtil alloc]init];
        
        [self initView];
    }
    return self;
}


-(void)initView
{
    float sz=54.0/255.0;
    
    self.backgroundColor=[UIColor colorWithRed:sz green:sz blue:sz alpha:1.0];
    
    [self initLeftPartView];
    
    [self initRightPartView];
}

//初始化创建左部分视图
-(void)initLeftPartView
{
    float h=(ScreenHeight/9)*5;
    float btnw=42;
    float btnh=38;
    
    leftPartView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, h)];
 
    
    leftPartView.backgroundColor=[UIColor clearColor];
    [self addSubview:leftPartView];
    
    //左菜单按钮
    self.menuBtn=[[UIButton alloc]initWithFrame:CGRectMake(ScreenWidth-btnw, 0, btnw, btnh)];
    [CommonUtil setBgOnBtn:self.menuBtn withImage:@[@"caidan.png",@"caidan.png"]];
    [leftPartView addSubview:self.menuBtn];
    
    
    
    //返回按钮
    self.backBtn=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, btnw, btnh)];
    [self.backBtn addTarget:self action:@selector(back:) forControlEvents:UIControlEventTouchUpInside];
    [CommonUtil setBgOnBtn:self.backBtn withImage:@[@"fanhui.png",@"fanhui.png"]];
    
    
    //分享图片
    
    float y=20;
    float w=ScreenWidth/2-30;
    float imgh=h-60;
    float x=(ScreenWidth-w)/2;
    
    self.shareImageView=[[UIImageView alloc]initWithFrame:CGRectMake(x, y, w, imgh)];
    self.shareImageView.backgroundColor=[UIColor whiteColor];
    self.shareImageView.transform=CGAffineTransformRotate(CGAffineTransformIdentity, -10*(M_PI/180));;
    [leftPartView addSubview:self.shareImageView];
    
    [leftPartView addSubview:self.backBtn];
    
}


//返回
-(void)back:(UIButton *)sender
{
    [self removeFromSuperview];
}

#define itemH 40

//初始化右部分
-(void)initRightPartView
{
    float y=CGRectGetHeight(leftPartView.frame);
    float w=ScreenHeight-y;
    
    CGAffineTransform transform=CGAffineTransformRotate(CGAffineTransformIdentity, 90*(M_PI/180));
    
    
    rightPartView=[[UIView alloc]initWithFrame:CGRectMake(0, y, w,ScreenWidth )];
    rightPartView.transform=CGAffineTransformTranslate(transform, -60, -55);

    rightPartView.backgroundColor=[UIColor greenColor];
    [self addSubview:rightPartView];
    
    float pt=5;
    float x=0;
    y=pt;
    float h=itemH*4;
    //分享模块容器
    shareViewContainer=[[UIView alloc]initWithFrame:CGRectMake(x, y, w, h)];
    shareViewContainer.layer.borderColor=[[UIColor blackColor] CGColor];
    shareViewContainer.layer.borderWidth=2;
    shareViewContainer.layer.cornerRadius=2;
    [rightPartView addSubview:shareViewContainer];
    
    y+=h+pt;
    h=70;
    //分享内容 CGRectMake(x, y, w, h)
    self.shareContentView=[[UITextView alloc]initWithFrame:CGRectMake(x, y, w, h)];
    self.shareContentView.backgroundColor=[UIColor whiteColor];
    
    [rightPartView addSubview:self.shareContentView];
    
    //发送分享内容按钮
    h=41;
    y=ScreenWidth-h-pt;
    self.sendShareBtn=[[UIButton alloc]initWithFrame:CGRectMake(x, y, w, h)];
    self.sendShareBtn.backgroundColor=[UIColor blackColor];
    [rightPartView addSubview:self.sendShareBtn];
    
   /***
    float w=42;
    float p=10;
    float pl=5;
    float h=CGRectGetHeight(rightPartView.frame)-p;
     y=p/2;
    float x=pl;
    //发送按钮
    self.sendShareBtn=[[UIButton alloc]initWithFrame:CGRectMake(x, y, w, h)];
    self.sendShareBtn.backgroundColor=[UIColor blackColor];
    [rightPartView addSubview:self.sendShareBtn];
    
    //分享内容
    x+=w+pl;
    w=55;
    self.shareContentView=[[UITextView alloc]initWithFrame:CGRectMake(x, y, w, h)];
    [rightPartView addSubview:self.shareContentView];
    
    
    
    shareViewContainer=[[UIView alloc]initWithFrame:CGRectMake(x, y, w, h)];
    
    [rightPartView addSubview:shareViewContainer];
    **/
    
}

@end
