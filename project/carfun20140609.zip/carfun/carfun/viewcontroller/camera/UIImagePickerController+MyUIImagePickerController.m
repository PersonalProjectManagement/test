//
//  UIImagePickerController+MyUIImagePickerController.m
//  carfun
//
//  Created by Piosa on 14-5-28.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "UIImagePickerController+MyUIImagePickerController.h"

@implementation UIImagePickerController (MyUIImagePickerController)

- (BOOL)shouldAutorotate
{
    return NO;
}

-(UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
{
    return UIInterfaceOrientationPortrait;
}
@end
