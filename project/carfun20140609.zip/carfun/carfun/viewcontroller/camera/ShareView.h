//
//  ShareView.h
//  carfun
//
//  Created by Piosa on 14-5-28.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommonUtil.h"
@interface ShareView : UIView
{
    UIView *leftPartView;
    
    UIView *rightPartView;
    
    CommonUtil *commonUtil;
    
    //分享部分
    UIView *shareViewContainer;
    
}
//菜单
@property(nonatomic,strong) UIButton *menuBtn;

//返回
@property(nonatomic,strong) UIButton *backBtn;

 //发送
@property(nonatomic,strong) UIButton *sendShareBtn;


//分享图片
@property(nonatomic,strong) UIImageView *shareImageView;


//分享的内容视图
@property(nonatomic,strong) UITextView *shareContentView;

//分享方式的集合
@property(nonatomic,strong) NSMutableArray *shareCateList;

//关闭
@property(nonatomic,strong) UIButton *closeBtn;
@end
