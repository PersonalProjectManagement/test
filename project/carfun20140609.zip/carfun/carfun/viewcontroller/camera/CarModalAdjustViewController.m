//
//  CarModalAdjustViewController.m
//  CustomPickerAndFitler
//
//  Created by Piosa on 14-2-19.
//  Copyright (c) 2014年 Wu.weibin. All rights reserved.
//

#import "CarModalAdjustViewController.h"

@interface CarModalAdjustViewController ()

@end

@implementation CarModalAdjustViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setWheels];
    
    [self setBottomView];
    
    scaelSize=5;
}



//该方法提供底部视图包含返回，照相选择车轮视图
-(void)setBottomView
{
    //屏幕尺寸
    CGSize size=[UIScreen mainScreen].bounds.size;
    //底部视图
    float bw=43;
    UIView *containerBottom=[[UIView alloc]initWithFrame:CGRectMake(0, 0, bw, size.height)];
    
    
    [self.view addSubview:containerBottom];
    
    containerBottom.backgroundColor=[UIColor greenColor];
    
    //循环底部按钮
    float y=0;
    float w=41;
    
    float x=(bw-w)/2;
    
    float paddingLeft=((size.height-w*wheels.count)/(wheels.count-1));
    
    for (int i=0; i<wheels.count; i++)
    {
        
        CGRect frame=CGRectMake(x, y, w, w);
        [containerBottom addSubview:[self getBtn:frame withImg:wheels[i] withTag:i ]];
        
        y=y+w+paddingLeft;
    }
    
    
    //放大缩小按钮
    UIButton *minus=[self getBtn:CGRectMake(200, 410, 47, 49) withImg:@"minus.png" withTag:wheels.count+1];
    
    UIButton *plus=[self getBtn:CGRectMake(250, 410, 47, 49) withImg:@"plus.png" withTag:wheels.count];
    
    
    
    [self.view addSubview:plus];
    [self.view addSubview:minus];
    
    
    //-------------------------------
    
    //一个和照相区域大小的图层
    
    
    container=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0,size.width , size.height)];
    // container.backgroundColor=[UIColor colorWithRed:0.23 green:0.12 blue:0.38 alpha:0.82];
    [self.view addSubview:container];
    
    cw=107;
    ch=183;
    w_scale=ch/cw;
    
    float addSize=0;
    
    cw+=addSize;
    ch+=addSize*w_scale;
    //车
    CGSize carSize=CGSizeMake(cw, ch);
    
    carModal=[self getImgView:CGRectMake(0, 0, carSize.width, carSize.height) withImg:@"car_modal.png"];
    
    
    
    float bh=containerBottom.bounds.size.width;
    centerPoint=CGPointMake((size.width-bh)/2+bh, size.height/2);
    
    carModal.center=centerPoint;
    
    [container addSubview:carModal];
    
    //轮子的位置
    
    float wheel_y=77;
    
    float wheel_x=64;
    
    float wheel_w=41;
    
    wheel_font=[self getImgView:CGRectMake(wheel_x, wheel_y, wheel_w, wheel_w) withImg:@"wheel_green.png"];
    
    wheel_behind=[self getImgView:CGRectMake(wheel_x, wheel_y+240, wheel_w, wheel_w) withImg:@"wheel_green.png"];
    
    
    //   wf_center=CGPointMake(centerPoint.x+carModal.frame.size.width/2-215.5, centerPoint.y-carModal.frame.size.height/2+106.2);
    
    wf_center=CGPointMake(centerPoint.x+carModal.frame.size.width/2-86.5 , centerPoint.y-carModal.frame.size.height/2+42.3);
    
    wheel_font.center=wf_center;
    
    wb_center=CGPointMake(wf_center.x, centerPoint.y+50.9);
    wheel_behind.center=wb_center;
    
    db_center=wb_center;
    df_center=wf_center;
    
    
    [container addSubview:wheel_font];
    
    [container addSubview:wheel_behind];
    
    
}


//得到UIImageView
-(UIImageView *)getImgView:(CGRect)frame withImg:(NSString *)imgname
{
    UIImageView *img=[[UIImageView alloc]initWithFrame:frame];
    [img setImage:[UIImage imageNamed:imgname]];
    return img;
}

//得到一个按钮
-(UIButton *)getBtn:(CGRect)frame withImg:(NSString *)img withTag:(int)tag
{
    UIButton *btn=[[UIButton alloc]initWithFrame:frame];
    btn.tag=tag;
    [btn addSubview:[self getImgView:CGRectMake(0, 0, frame.size.width, frame.size.height) withImg:img]];
    [btn addTarget:self action:@selector(changeWheel:) forControlEvents:UIControlEventTouchUpInside];
    
    return btn;
}


-(void)changeWheel:(UIButton *)sender
{
    [self setWheels];
    
    int tag=sender.tag;
    
    if (tag==0)
    {
        //返回
        [self dismissModalViewControllerAnimated:YES];
        
    }else if(tag==wheels.count-1)
    {
        //照相
        //[self takePicture];
    }else
    {
        int count=wheels.count;
        
        if (tag<count)
        {
            //设置车轮
            NSString *wheel=[wheels objectAtIndex:sender.tag];
            UIImage *img=[UIImage  imageNamed:wheel];
            [wheel_font setImage:img];
            [wheel_behind setImage:img];
            
        }else
        {
            //放大
            if (tag==count)
            {
                [self zoomInCarModal];
                
            }else if(tag==(count+1))
            {
                //缩小
                [self zoomOutCarModal];
            }
        }
        
    }
    
    
    
}

//设置模型的位置
//放大
-(void)zoomInCarModal
{
    float w=carModal.frame.size.width;
    float h=carModal.frame.size.height;
    
    float tw=w+scaelSize;
    float th=h+(scaelSize*w_scale);
    
    [self setCarModal:tw withH:th];
    
     scale=(tw-w)/w;
    
     w=wheel_font.frame.size.width;
    
    NSLog(@"tw=%f  th=%f",tw,th);
    
    //设置的轮子的中心点为默认
    if (tw==cw)
    {
        wf_center=df_center;
        wb_center=db_center;
        
    }else
    {        // wf_center=wheel_font.center;
        
        float x=wf_center.x-scaelSize/4-0.195;//reducingSize/2;
        float y=wf_center.y-(scaelSize*w_scale)/4-0.19;
        
        wf_center=CGPointMake(x, y);
        //后轮
        y=wb_center.y+(scaelSize*w_scale)/4+0.198;//198
        wb_center=CGPointMake(x, y);
    }
    
    
    [self setWheel:(w+scale*w)];
    
    
    wheel_font.center=wf_center;
    
    wheel_behind.center=wb_center;
    
    
}

//缩小
-(void)zoomOutCarModal
{
    float w=carModal.frame.size.width;
    float h=carModal.frame.size.height;
    //减小后的宽
    float tw=w-scaelSize;
    float th=h-(scaelSize*w_scale);
    
    [self setCarModal:tw withH:th];
    
    scale=(w-tw)/w;
    
    w=wheel_font.frame.size.width;
    
    
     NSLog(@"tw=%f  th=%f",tw,th);
    
    //设置的轮子的中心点为默认
    if (tw==cw)
    {
        wf_center=df_center;
        wb_center=db_center;
        
    }else
    {
      
        //前轮
//        wf_center=wheel_font.center;
        
        float x=wf_center.x+scaelSize/4+0.22;//0.28
        float y=wf_center.y+(scaelSize*w_scale)/4+0.187;//0.187
        
        wf_center=CGPointMake(x, y);
        
        NSLog(@"wf_center--x=%f  y=%f",wf_center.x,wf_center.y);
        
        //后轮
        y=wb_center.y-(scaelSize*w_scale)/4-0.197;//0.197
        wb_center=CGPointMake(x, y);
    }
    
    
    [self setWheel:(w-scale*w)];
    
    
    wheel_font.center=wf_center;
    
    wheel_behind.center=wb_center;
    
    
}


//设置轮子的直径
-(void)setWheel:(float)diameter
{
    wheel_behind.frame=CGRectMake(0, 0, diameter, diameter);
    wheel_font.frame=CGRectMake(0, 0, diameter, diameter);
    
}

//设置模型的宽高
-(void)setCarModal:(float)w withH:(float)h
{
    carModal.frame=CGRectMake(0, 0, w, h);
    carModal.center=centerPoint;
}


-(void)setWheels
{
    wheels=@[@"back.png",@"wheel_blue.png",@"wheel_rg.png",@"wheel_green.png",@"wheel_blue.png",@"wheel_pink.png",@"wheel_green.png",@"confirm.png"];
}



@end
