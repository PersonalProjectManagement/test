//
//  CustomImagePickerController.m
//  MeiJiaLove
//
//  Created by Wu.weibin on 13-7-9.
//  Copyright (c) 2013年 Wu.weibin. All rights reserved.
//

#import "CarFanCustomImagePickerControllerViewController.h"

#import "ShareImageViewController.h"

#import "MenuView.h"


@interface CarFanCustomImagePickerControllerViewController()
{
    MenuView *menuView;
}
@end

@implementation CarFanCustomImagePickerControllerViewController

 


- (BOOL)shouldAutorotate {
    return NO;
}

-(NSUInteger)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}



#pragma mark get/show the UIView we want
- (UIView *)findView:(UIView *)aView withName:(NSString *)name {
	Class cl = [aView class];
	NSString *desc = [cl description];
	
	if ([name isEqualToString:desc])
		return aView;
	
	for (NSUInteger i = 0; i < [aView.subviews count]; i++) {
		UIView *subView = [aView.subviews objectAtIndex:i];
		subView = [self findView:subView withName:name];
		if (subView)
			return subView;
	}
	return nil;
}

//-------------------------------------------

//-------------------------------------------
#pragma mark UINavigationControllerDelegate
- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    NSLog(@"willShowViewController");
    
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    
    
    if(self.sourceType == UIImagePickerControllerSourceTypeCamera)
    {
        commonUtil=[[CommonUtil alloc]init];
        
        
        menuView=[[MenuView alloc] initWithFrame:self.view.frame withSuperView:self.view];
        menuView.imagePickerController=self;
        
        [self initSizeAndData];
        
        //照相后显示的图片
        //照相后的图片显示视图
        imageView=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
        
        imageView.backgroundColor=[UIColor colorWithRed:0.2 green:0.6 blue:0.2 alpha:0.2];
        
        [self.view addSubview:imageView];
        
        
        
        //打水印的图片
        
        [self initWatermarkView];
        
        //界面操作按钮
        
        [self setInitPanelBtn];
        
        
        //设置部分视图的显示和隐藏
        [self setViewHidden:!isShareBack];
        
        if (isShareBack)
        {
            alreadyTaked=YES;
            
            ispop=NO;
            
            [self setImageAfterTakeToView];
            
            [self setWheelOnTheCar:wheels[self.currentSelectedWheelIndex]];
            
            
            [self setCurrentSelectedWheel:currentSelectedWheelBtn];
        }
        
        
       // [self initMenu];
       [self initMenuView];
        
        
        
        //        [self.view addSubview:menuView.left];
        
        //隐藏Camera控制器原有的UI
        [self setShowsCameraControls:NO];
        
    }
}


-(void)showLeftMenuBtn
{
    leftMenuBtn.hidden=NO;
}
//初始化菜单视图
-(void)initMenuView
{
       // menuView.isCameraInvoke=YES;
    
  //  menuView.frame=CGRectMake(0, 0, 100, 100);
    
    menuView.userInteractionEnabled=NO;
   
    menuView.backgroundColor=[UIColor clearColor];//[UIColor colorWithRed:0.8 green:0.2 blue:0.6 alpha:0.6];
    
    CGAffineTransform transform=CGAffineTransformRotate(CGAffineTransformIdentity, 90*(M_PI/180));
    
                                                //    y     x
    // transform= CGAffineTransformTranslate(transform, 0, -220);// 80, 80
    
    
    transform= CGAffineTransformTranslate(transform, -80, 80);// 80, 80
    
    menuView.transform=transform;
    
//    [menuView setMenuFrame:CGRectMake(leftMenuBtn.frame.origin.x, leftMenuBtn.frame.origin.y, CGRectGetWidth(leftMenuBtn.frame),CGRectGetHeight(leftMenuBtn.frame))];
//    
//    menuView.menuBtn.transform=transform;
    
    //   menuView.menuBtn.frame=CGRectMake(leftMenuBtn.frame.origin.x, leftMenuBtn.frame.origin.y, CGRectGetHeight(leftMenuBtn.frame), CGRectGetWidth(leftMenuBtn.frame));
    
  //  [self setBgOnBtn:menuView.menuBtn withImage:@[@"caidan.png",@"caidan.png"]];
    
    menuView.uiViewController=self.uiViewController;
    menuView.carFanController=self;
    
  [self.view addSubview:menuView];
    
  //  UIWindow *window=SharedApp.window;
    
 //   [window addSubview:menuView];
    
    
    
}




//初始化尺寸
-(void)initSizeAndData
{
    if (self.imageAfterTake)
    {
        isShareBack=YES;
    }else
    {
        isShareBack=NO;
    }
    
    float w=140;
    
    float h=440;
    
    wheelDiameter=66;
    
    if (ScreenHeight==480)
    {
        w=126;
        h=400;
        
        wheelDiameter=58;
    }
    
    
    float x=(ScreenWidth-w)/2;
    
    float y=(ScreenHeight-h)/2;
    carFrame=CGRectMake(x, y, w, h);
    
    wheels=@[@"1.png",@"2.png",@"3.png",@"4.png",@"5.png",@"6.png",@"7.png",@"8.png"];
}





//根据传入的图片设置按钮背景
-(void)setBgOnBtn:(UIButton *)btn withImage:(NSArray *)imgs
{
    [btn setImage:[UIImage imageNamed:imgs[0]] forState:UIControlStateNormal];
    [btn setImage:[UIImage imageNamed:imgs[1]] forState:UIControlStateHighlighted];
}




/**
 设置左菜单，返回和ok按钮
 ***/
-(void)setInitPanelBtn
{
    //overlayView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight)];
    // [self.view addSubview:overlayView];
    
    // overlayView.backgroundColor=[UIColor clearColor];
    
    
    // overlayView.backgroundColor=[UIColor colorWithRed:0.2 green:0.6 blue:0.8 alpha:0.3];
    
    float btnw=MENU_HEIGHT;
    float btnh=MENU_WIDHT;
    
    UIImage *image=[UIImage imageNamed:@"tbview.png"];
    //顶部斜线视图
    float w=btnw-10;
    topView=[[UIImageView alloc]initWithFrame:CGRectMake(ScreenWidth-w, 0, w, ScreenHeight)];
    topView.image=image;
    [self.view addSubview:topView];
    
    bottomView=[[UIImageView alloc]initWithFrame:CGRectMake(0, btnh, w, ScreenHeight-2*btnh)];
    bottomView.image=image;//[UIColor colorWithRed:0.2 green:0.9 blue:0.1 alpha:0.4];
    [self.view addSubview:bottomView];
    
    //左右两侧白色视图
    
    //白色视图的高,宽
    float wh=btnh-8;
    
    if (ScreenHeight==480) {
        wh-=6;
    }
    
    float ww=50;
    //上
    
    [self.view addSubview:[self getWhiteView:CGRectMake(0, 0, ScreenWidth, wh)]];
    
    //下
    [self.view addSubview:[self getWhiteView:CGRectMake(0, ScreenHeight-wh, ScreenWidth, wh)]];
    
    //左
    bottomLunQuanView=[self getWhiteView:CGRectMake(0, 0, ww, ScreenHeight)];
    
    [self.view addSubview:bottomLunQuanView];
    
    
    [self.view addSubview:bottomColumnView];
    
    
    
    
    
    //左菜单按钮
    leftFrame=CGRectMake(ScreenWidth-btnw, 0, btnw, btnh);
    leftMenuBtn=[[UIButton alloc]initWithFrame:leftFrame];
    
    [leftMenuBtn addTarget:self action:@selector(showLeftMenu:) forControlEvents:UIControlEventTouchUpInside];
    
    [self setBgOnBtn:leftMenuBtn withImage:@[@"caidan.png",@"caidan.png"]];
    
    
    
    [self.view addSubview:leftMenuBtn];
    
    
    
    //返回按钮
    backBtn=[[UIButton alloc]initWithFrame:CGRectMake(0, 0, btnw, btnh)];
    [self setBgOnBtn:backBtn withImage:@[@"fanhui.png",@"fanhui.png"]];
    [backBtn  addTarget:self action:@selector(backEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:backBtn];
    
    
    //ok按钮
    okBtn=[[UIButton alloc]initWithFrame:CGRectMake(0, ScreenHeight-btnh, btnw, btnh)];
    [self setBgOnBtn:okBtn withImage:@[@"OK.png",@"OK.png"]];
    [okBtn addTarget:self action:@selector(takePicture) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:okBtn];
    
    
    //放大缩小按钮的宽度
    float h=33;
    w=43;
    
    float funcationX=(ScreenWidth-w*2)/2;
    float funcationY=(ScreenHeight-(h+wh-h/2));
    
    //缩小按钮
    zoomOutBtn=[[UIButton alloc]initWithFrame:CGRectMake(funcationX, funcationY, w, h)];
    [self setBgOnBtn:zoomOutBtn withImage:@[@"sx.png",@"sx.png"]];
    [zoomOutBtn addTarget:self action:@selector(zoomOutEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:zoomOutBtn];
    
    
    
    funcationX+=w;
    
    //放大按钮
    zoomInBtn=[[UIButton alloc]initWithFrame:CGRectMake(funcationX, funcationY, w, h)];
    [self setBgOnBtn:zoomInBtn withImage:@[@"fd.png",@"fd.png"]];
    [zoomInBtn addTarget:self action:@selector(zoomInEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:zoomInBtn];
    
    w=45;
    funcationX=(ScreenWidth-w)/2+25;
    
    funcationY=wh-w/2;
    
    seeBigViewBtn=[[UIButton alloc]initWithFrame:CGRectMake(funcationX, funcationY, w,w)];
    [self setBgOnBtn:seeBigViewBtn withImage:@[@"dtsf.png",@"dtsf.png"]];
    [seeBigViewBtn addTarget:self action:@selector(seeBigViewBtnEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:seeBigViewBtn];
    
    
    [self setWheelToBottomView];
    
    
}


-(void)showLeftMenu:(UIButton *)sender
{
    sender.hidden=YES;
    [menuView showLeft];
    
}

//设置轮圈到底部轮圈视图中
-(void)setWheelToBottomView
{
    float wh=CGRectGetWidth(bottomLunQuanView.frame)-2;
    
    float paddingLeft=2;
    
    float y=CGRectGetHeight(backBtn.frame);
    
    float x=1;
    int count=(wheels.count-1);
    
    for (int i=count; i>=0; i--)
    {
        y+=paddingLeft;
        UIButton *btn=[[UIButton alloc]initWithFrame:CGRectMake(x, y, wh, wh)];
        btn.tag=i;
        btn.backgroundColor=[UIColor clearColor];
        [btn addTarget:self action:@selector(setWheelToCart:) forControlEvents:UIControlEventTouchUpInside];
        
        [self setBgOnBtn:btn withImage:@[wheels[i],wheels[i]]];
        [bottomLunQuanView addSubview:btn];
        
        if (i==count)
        {
            [btn addSubview:[self getStateView:btn]];
        }
        
        if (i==self.currentSelectedWheelIndex)
        {
            currentSelectedWheelBtn=btn;
        }
        
        y+=wh;
    }
    
}

//当前选中车轮的状态标志Imageview视图的Tag
#define STATE_IMG_TAG   99

//设置轮圈到车上
-(void)setWheelToCart:(UIButton *)sender
{
    NSLog(@"sender index=%d",sender.tag);
    //设置当前选择的轮圈索引
    self.currentSelectedWheelIndex=sender.tag;
    
    [self setCurrentSelectedWheel:sender];
    
    
    //隐藏显示的实物图
    wheelEntityView.hidden=YES;
    
}

//设置当前选中的轮圈
-(void)setCurrentSelectedWheel:(UIButton *)sender
{
    [self setWheelOnTheCar:wheels[sender.tag]];
    
    //删除所有轮圈视图中存在的状态图片
    NSArray *subview=[bottomLunQuanView subviews];
    
    for (int i=0; i<subview.count; i++)
    {
        UIView *v=subview[i];
        UIView *stateView=[v viewWithTag:STATE_IMG_TAG];
        
        if (stateView)
        {
            [stateView removeFromSuperview];
            
        }
    }
    
    [sender addSubview:[self getStateView:sender]];
}

//得到状态图片
-(UIView *)getStateView:(UIButton *)superView
{
    float w=25;
    float h=25;
    float x=CGRectGetWidth(superView.frame)-w+3;
    float y=CGRectGetHeight(superView.frame)-h;
    
    UIImageView *stateImageView=[[UIImageView alloc]initWithFrame:CGRectMake(x, y, w, h)];
    stateImageView.image=[UIImage imageNamed:@"dqxz.png"];
    stateImageView.tag=STATE_IMG_TAG;
    return stateImageView;
}


//设置前轮和后轮的图片
-(void)setWheelOnTheCar:(NSString *)imageName
{
    currentSelectedWheelImage=[UIImage imageNamed:imageName];
    
    //    [self setBgOnBtn:wheel_front withImage:@[imageName,imageName]];
    //    [self setBgOnBtn:wheel_behind withImage:@[imageName,imageName]];
    
    wheel_front.image=currentSelectedWheelImage;
    wheel_behind.image=currentSelectedWheelImage;
}

//根据传入的值对部分视图进行隐藏显示
-(void)setViewHidden:(BOOL)isHidden
{
    seeBigViewBtn.hidden=isHidden;
    
    zoomInBtn.hidden=isHidden;
    zoomOutBtn.hidden=isHidden;
    bottomLunQuanView.hidden=isHidden;
    wheelEntityView.hidden=isHidden;
    
    wheel_front.hidden=isHidden;
    wheel_behind.hidden=isHidden;
    
    wheel_behind.center=defaultBackWheelPoint;
    wheel_front.center=defaultFrontWheelPoint;
    
    
    /*
     if (isHidden)
     {
     carModal.hidden=NO;
     }else
     {
     carModal.hidden=YES;
     }
     **/
    
    
}

//放大轮圈事件
-(void)zoomInEvent:(UIButton *)sender
{
    NSLog(@"---zoomIn----");
    
    float diameter=CGRectGetHeight(wheel_behind.frame);
    
    diameter+=1;
    
    [self setWheelDiameter:diameter];
    
}

//缩小轮圈事件
-(void)zoomOutEvent:(UIButton *)sender
{
    NSLog(@"---zoomOutEvent----");
    
    float diameter=CGRectGetHeight(wheel_behind.frame);
    
    diameter-=1;
    
    [self setWheelDiameter:diameter];
    
}


-(void)setWheelDiameter:(float)diameter
{
    CGPoint point=wheel_front.center;
    wheel_front.frame=CGRectMake(0, 0, diameter, diameter);
    wheel_front.center=point;
    
    [self setRaCircularBead:wheel_front];
    
    point=wheel_behind.center;
    wheel_behind.frame=CGRectMake(0, 0, diameter, diameter);
    wheel_behind.center=point;
    
    [self setRaCircularBead:wheel_behind];
    
}




//大图缩放事件
-(void)seeBigViewBtnEvent:(UIButton *)sender
{
    NSLog(@"---seeBigViewBtnEvent----");
    
    if (!wheelEntityView)
    {
        float w=150;
        wheelEntityView=[[UIImageView alloc]initWithFrame:CGRectMake((ScreenWidth-w)/2, (ScreenHeight-w)/2, w, w)];
        wheelEntityView.hidden=YES;
        [self.view addSubview:wheelEntityView];
    }
    
    
    if (wheelEntityView.hidden)
    {
        wheelEntityView.hidden=NO;
        wheelEntityView.image=currentSelectedWheelImage;
    }else
    {
        wheelEntityView.hidden=YES;
    }
    
}


//根据传入的的Frame返回一个白色视图
-(UIView *)getWhiteView:(CGRect)frame
{
    UIView *v=[[UIView alloc]initWithFrame:frame];
    
    v.backgroundColor=[UIColor whiteColor];
    
    return v;
}

//该方法设置轮子用户设置的轮子视图,也就是添加到照相后的图片上的水印视图
-(void)initWatermarkView
{
    //车的模型
    carModal=[[UIImageView alloc]initWithFrame:carFrame];
    carModal.image=[UIImage imageNamed:@"camera_car_modal.png"];
    carModal.backgroundColor=[UIColor clearColor];
    [self.view addSubview:carModal];
    
    
    
    
    //轮圈栏的宽度
    // float wheelColW=CGRectGetWidth(bottomLunQuanView.frame);
    
    //设置在车上的轮子视图
    //wheelColW, carModalFrame.origin.y,  (ScreenWidth-wheelColW*2), CGRectGetHeight(carModalFrame)
    
    overlayWatermark=[[UIView alloc]initWithFrame:CGRectMake(0,0,ScreenWidth,ScreenHeight)];
    
    //  overlayWatermark.backgroundColor=[UIColor colorWithRed:0.8 green:0.2 blue:0.4 alpha:0.6];
    
    overlayWatermark.backgroundColor=[UIColor clearColor];
    
    
    //设置两个轮子在视图上
    
    float carx=(1+carFrame.origin.x);
    
    
    float carh=CGRectGetHeight(carFrame);
    
    //车模型的Y
    float carModalY=carFrame.origin.y;
    
    //5s
    float wheelY=38+carModalY;
    
    //4s
    if (ScreenHeight==480)
    {
        wheelY=36+carFrame.origin.y;
    }
    
    //前轮
    wheel_front=[[UIImageView alloc]initWithFrame:CGRectMake(carx, wheelY, wheelDiameter, wheelDiameter)];
    
    float r=wheelDiameter/2;
    
    defaultFrontWheelPoint=CGPointMake(carx+r, wheelY+r);
    
    wheel_front.center=defaultFrontWheelPoint;
    
    
    
    //5s
    wheelY=65;
    
    //4s
    if (ScreenHeight==480)
    {
        wheelY=60;
    }
    
    wheelY= carh-wheelY-wheelDiameter+carModalY;
    
    wheel_behind=[[UIImageView alloc]initWithFrame:CGRectMake(carx,wheelY, wheelDiameter, wheelDiameter)];
    
    defaultBackWheelPoint=CGPointMake(carx+r, wheelY+r);
    wheel_behind.center=defaultBackWheelPoint;
    
    [self setRaCircularBead:wheel_behind];
    [self setRaCircularBead:wheel_front];
    
    [overlayWatermark addSubview:wheel_front];
    
    
    [overlayWatermark addSubview:wheel_behind];
    
    //   overlayWatermark.backgroundColor=[UIColor colorWithRed:0.3 green:0.4 blue:0.2 alpha:0.3];
    
    panGestureRecognizerFrontWheel = [[UIPanGestureRecognizer alloc]
                                      initWithTarget:self
                                      action:@selector(handlePan:)];
    
    
    
    panGestureRecognizerBehindWheel = [[UIPanGestureRecognizer alloc]
                                       initWithTarget:self
                                       action:@selector(handlePan:)];
    
    wheel_front.userInteractionEnabled=YES;
    wheel_front.multipleTouchEnabled=YES;
    
    wheel_behind.userInteractionEnabled=YES;
    wheel_behind.multipleTouchEnabled=YES;
    
    [wheel_front addGestureRecognizer:panGestureRecognizerFrontWheel];
    
    [wheel_behind addGestureRecognizer:panGestureRecognizerBehindWheel];
    
    
    
    
    [self.view addSubview:overlayWatermark];
    
    
}

-(void)test
{
    NSLog(@"tets--------");
}




//拖动轮子的手势
-(void)handlePan:(UIPanGestureRecognizer *)gesture
{
    CGPoint translation = [gesture translationInView:overlayWatermark];
    
    float x=translation.x;
    
    float y=translation.y;
    
    NSLog(@"x=%f  y=%f",x,y);
    
    //    if (CGRectContainsPoint(overlayWatermark.frame, translation))
    //    {
    gesture.view.center = CGPointMake(gesture.view.center.x + translation.x,
                                      gesture.view.center.y + translation.y);
    
    [gesture setTranslation:CGPointZero inView:overlayWatermark];
    // }
    
}

//传入视图设置圆角
-(void)setRaCircularBead:(UIView *)v
{
    float r=CGRectGetWidth(v.frame);
    v.layer.cornerRadius=r/2;
    v.layer.borderWidth=1;
    v.layer.borderColor=[[UIColor redColor] CGColor];
}


//返回上一个页面或退出当前照相
-(void)backEvent:(UIButton *)sender
{
    if (ispop)
    {
        alreadyTaked=NO;
        [self.externalNavgation popViewControllerAnimated:YES];
        [self dismissViewControllerAnimated:YES completion:^{
            
        }];
    }else
    {
        imageView.hidden=YES;
        ispop=YES;
        alreadyTaked=NO;
        
        [self setViewHidden:YES];
    }
}


- (void)takePicture
{
    //隐藏右菜单
    
    [menuView hideMenu];
    
    
    if (alreadyTaked)
    {
        NSLog(@"----share-----");
        
        //截图
        UIImage *imageShuiYin=[self ScreenShots:overlayWatermark];
        
        //缩放
        imageShuiYin=[self scaleImage:imageShuiYin];
        
        //对照相的图片空间进行截图
        self.imageAfterTake=imageView.image;
        
        UIImage *zhaoxiang=[self ScreenShots:imageView];;
        
        //旋转
        zhaoxiang= [commonUtil rotateImage:zhaoxiang withImageOrientationi:UIImageOrientationDown];
        
        //将屏幕截图和照相后得到的图片进行合并
        finallyImage=[self addImage:zhaoxiang toImage:imageShuiYin];
        
        
        //旋转
        finallyImage= [commonUtil rotateImage:finallyImage withImageOrientationi:UIImageOrientationLeft];
        
        /*  ShareView *share=[[ShareView alloc]initWithFrame:self.view.frame];
         
         share.shareImageView.image=finallyImage;
         
         [self.view addSubview:share];
         **/
        
        
        ShareImageViewController *vc=[[ShareImageViewController alloc]init];
        vc.image=finallyImage;
        vc.imageAfterTake=self.imageAfterTake;
        vc.currentSelectedWheelIndex=self.currentSelectedWheelIndex;
        [self.externalNavgation pushViewController:vc animated:YES];
        
        
        [self dismissViewControllerAnimated:YES completion:^{
        }];
        
        
    }else
    {
        ispop=NO;
        
        [super takePicture];
    }
    
}





//当合并图片的时候对照相后得到的图片进行旋转
-(UIImage *)rotate3:(float)angleInRadians withImage:(UIImage *)imageO withSize:(CGSize)size
{
    angleInRadians=angleInRadians*(M_PI/180);
    
    //CGSize size =CGSizeMake(129, 139);
    UIGraphicsBeginImageContext(size);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextRotateCTM(ctx, angleInRadians);
    
    //  CGContextTranslateCTM(ctx, -size.height, -0);
    
    [imageO drawInRect:CGRectMake(0,0,size.height, size.width)];
    
    // CGContextDrawImage(ctx, CGRectMake(0,0,size.height, size.width), [imageO CGImage]);
    //
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return image;
    
}


-(BOOL)prefersStatusBarHidden
{
    return YES;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    NSLog(@"viewDidLoad");
    self.navigationBarHidden=YES;
    
    ispop=YES;
    
    self.delegate = self;
    
    scaelSize=5;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - ButtonAction Methods

- (IBAction)swapFrontAndBackCameras:(id)sender {
    if (self.cameraDevice ==UIImagePickerControllerCameraDeviceRear ) {
        self.cameraDevice = UIImagePickerControllerCameraDeviceFront;
    }else {
        self.cameraDevice = UIImagePickerControllerCameraDeviceRear;
    }
}



#pragma mark Camera View Delegate Methods
- (void)imagePickerController:(UIImagePickerController *)picker
didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
    
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    
    float w=image.size.width;
    float h=image.size.height;
    
    float ow=ScreenWidth;
    float oh=ScreenHeight;
    
    float xscaleSize=w/ow;
    
    float yscaleSize=h/oh;
    
    //对当前照相后得到的图片进行缩放操作
    image=[image scaleImage:image toXScale:xscaleSize withYScal:yscaleSize];
    
    
    [self dealPicAfterTakePhoto:image];
}


#pragma -mark 根据传入的照相图片进行处理
-(void)dealPicAfterTakePhoto:(UIImage *)image
{
    
    image=[self rotate2:270 withImage:image withSize:CGSizeMake(image.size.width, image.size.height)];
    
    self.imageAfterTake=image;
    
    [self setImageAfterTakeToView];
    
    ispop=NO;
    
    [self setWheelOnTheCar:wheels[0]];
    
    [self setViewHidden:NO];
    
    wheelEntityView.hidden=YES;
    
    //记录用户已经点击过拍照了
    alreadyTaked=YES;
    
}


//将拍照后的图片设置到显示视图上
-(void)setImageAfterTakeToView
{
    imageView.image=self.imageAfterTake;
    
    imageView.hidden=NO;
    
    imageView.transform=CGAffineTransformRotate(CGAffineTransformIdentity, 180*(M_PI/180));
}


- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    /*
     [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleBlackOpaque animated:YES];
     if(_isSingle){
     [picker dismissModalViewControllerAnimated:YES];
     }else{
     if(picker.sourceType == UIImagePickerControllerSourceTypePhotoLibrary){
     self.sourceType = UIImagePickerControllerSourceTypeCamera;
     }else{
     [picker dismissModalViewControllerAnimated:YES];
     }
     }*/
}

//截屏
- (UIImage *) ScreenShots:(UIView *)cv {
    
    
    UIImage *screenImage;
    UIGraphicsBeginImageContext(cv.frame.size);
    [cv.layer renderInContext:UIGraphicsGetCurrentContext()];
    screenImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return screenImage;
}

#pragma -mark 截图
//------------------------------------------------
//截图
//------------------------------------------------
-(UIImage *)ScreenShotse
{
    
    CGSize imageSize = [[UIScreen mainScreen] bounds].size;
    if (NULL != UIGraphicsBeginImageContextWithOptions) {
        UIGraphicsBeginImageContextWithOptions(imageSize, NO, 0);
    }
    else
    {
        UIGraphicsBeginImageContext(imageSize);
    }
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    for (UIWindow * window in [[UIApplication sharedApplication] windows]) {
        if (![window respondsToSelector:@selector(screen)] || [window screen] == [UIScreen mainScreen]) {
            CGContextSaveGState(context);
            CGContextTranslateCTM(context, [window center].x, [window center].y);
            CGContextConcatCTM(context, [window transform]);
            CGContextTranslateCTM(context, -[window bounds].size.width*[[window layer] anchorPoint].x, -[window bounds].size.height*[[window layer] anchorPoint].y);
            [[window layer] renderInContext:context];
            
            CGContextRestoreGState(context);
        }
    }
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    NSLog(@"Suceeded!");
    
    return image;
}



#pragma -mark 对图片进行旋转，合并图片等操作
//--------------------------
//--------旋转图片
//---------------------------


-(UIImage *)rotate2:(float)angleInRadians withImage:(UIImage *)imageO withSize:(CGSize)size
{
    angleInRadians=angleInRadians*(M_PI/180);
    
    //CGSize size =CGSizeMake(129, 139);
    UIGraphicsBeginImageContext(size);
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    CGContextRotateCTM(ctx, angleInRadians);
    
    CGContextTranslateCTM(ctx, -size.height, -0);
    
    [imageO drawInRect:CGRectMake(0,0,size.height, size.width)];
    
    // CGContextDrawImage(ctx, CGRectMake(0,0,size.height, size.width), [imageO CGImage]);
    //
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
    
}




//将两张图片合成一张图片
- (UIImage *)addImage:(UIImage *)image1 toImage:(UIImage *)image2 {
    
    [self pirnt:image1];
    
    [self pirnt:image2];
    
    //  image2=[image2 rotateImageWithRadian:270 cropMode:enSvCropClip];
    
    UIGraphicsBeginImageContext(image1.size);
    
    // Draw image1
    [image1 drawInRect:CGRectMake(0, 0, image1.size.width, image1.size.height)];
    
    // Draw image2
    [image2 drawInRect:CGRectMake(0, 0, image2.size.width, image2.size.height)];
    
    UIImage *resultingImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return resultingImage;
    
    
}

//------------------------
//图片缩放
//------------------------
-(UIImage *)scaleImage:(UIImage *)image
{
    CGSize size=CGSizeMake(ScreenWidth, ScreenHeight);
    UIGraphicsBeginImageContext(CGSizeMake(size.width,size.height));
    [image drawInRect:CGRectMake(0, 0, size.width,size.height)];
    UIImage *scaledImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return scaledImage;
    
}


-(void)pirnt:(UIImage *)img
{
    NSLog(@"w=%f   h=%f",img.size.width,img.size.height);
}




@end
