//
//  ShareImageViewController.h
//  carfun
//
//  Created by Piosa on 14-5-29.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "ParentViewViewController.h"
#import "CommonUtil.h"
@interface ShareImageViewController : ParentViewViewController
{
    UIView *leftPartView;
    
    UIView *rightPartView;
    
    CommonUtil *commonUtil;
    
    //分享部分
    UIView *shareViewContainer;
    
    UIColor *lineColor;
    
    //距离上面的距离
    float pt;
    
    NSArray *shareList;
}
//菜单
@property(nonatomic,strong) UIButton *menuBtn;

//返回
@property(nonatomic,strong) UIButton *backBtn;

//发送
@property(nonatomic,strong) UIButton *sendShareBtn;


//分享图片
@property(nonatomic,strong) UIImageView *shareImageView;


//分享的内容视图
@property(nonatomic,strong) UITextView *shareContentView;

//分享方式的集合
@property(nonatomic,strong) NSMutableArray *shareCateList;

//关闭
@property(nonatomic,strong) UIButton *closeBtn;


@property(nonatomic,strong) UIImageView *imageView;

//合并后得到的图片
@property(nonatomic,strong) UIImage *image;

//照相后得到的图片
@property(nonatomic,strong) UIImage *imageAfterTake;


//记录选择轮子的索引
@property int currentSelectedWheelIndex;

@end
