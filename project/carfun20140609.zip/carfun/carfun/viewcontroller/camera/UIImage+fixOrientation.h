//
//  UIImage+fixOrientation.h
//  CustomPickerAndFitler
//
//  Created by Piosa on 14-2-14.
//  Copyright (c) 2014年 Wu.weibin. All rights reserved.
//

#import <UIKit/UIKit.h>
#include <math.h>

#define IMAGE_MAX_SIZE_WIDTH 320
#define IMAGE_MAX_SIZE_GEIGHT 480

enum {
    enSvCropClip,               // the image size will be equal to orignal image, some part of image may be cliped
    enSvCropExpand,             // the image size will expand to contain the whole image, remain area will be transparent
};
typedef NSInteger SvCropMode;

@interface UIImage (fixOrientation)
    -(UIImage *)fixOrientation;


-(UIImage *)fitSmallImage:(UIImage *)image;



    -(UIImage*)rotateImageWithRadian:(CGFloat)radian cropMode:(SvCropMode)cropMode;


//图片缩放
-(UIImage *)scaleImage:(UIImage *)image toXScale:(float)xscaleSize withYScal:(float)
yscaleSize;

@end


