//
//  UIImagePickerController+MyUIImagePickerController.h
//  carfun
//
//  Created by Piosa on 14-5-28.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImagePickerController (MyUIImagePickerController)

-(BOOL)shouldAutorotate;
@end
