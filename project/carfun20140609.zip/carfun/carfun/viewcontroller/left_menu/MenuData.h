//
//  MenuData.h
//  carfun
//提供菜单列表所需数据
//  Created by Piosa on 14-4-3.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MenuData : NSObject

//------------------
//车迷站菜单项部分
//------------------
-(NSArray *)cheMiZhanMenu;


//--------------------
//SRrcer菜单项部分
//--------------------
-(NSArray *)SRrcerMenuData;


//------------------
//---BC菜单数据项部分
//------------------
-(NSArray *)BCData;



//--------------------
//BC-other菜单项部分
//--------------------
-(NSArray *)BCOtherMenuData;

@end
