//
//  MenuData.m
//  carfun
//
//  Created by Piosa on 14-4-3.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import "MenuData.h"
//车迷站
#import "IndexViewController.h"
#import "MapViewController.h"
#import "CMZJianJieViewController.h"
#import "SRJianJieViewController.h"
#import "BCJianJieViewController.h"
#import "BCLunQuanJianJieViewController.h"
#import "HeZuoShangJiaAddrViewController.h"

//BC
#import "LunQuanCheZhaoViewController.h"
#import "DetailViewController.h"


//SRrcer
#import "SRrcerDetailViewController.h"

//BC-Other
#import "BCOtherDetailViewController.h"

@implementation MenuData


//--------------------
//车迷站菜单项部分
//--------------------
-(NSArray *)cheMiZhanMenu
{
    NSMutableArray *list=[[NSMutableArray alloc]initWithCapacity:5];
    
    
    [list addObject:[self getMenuItem:@"车迷站公司简介" withVC:[[CMZJianJieViewController alloc]init]]];
    
    [list addObject:[self getMenuItem:@"SR刹车简介" withVC:[[SRJianJieViewController alloc]init]]];
    
    [list addObject:[self getMenuItem:@"BC避震简介" withVC:[[BCJianJieViewController alloc]init]]];
    
    [list addObject:[self getMenuItem:@"BC轮圈简介" withVC:[[BCLunQuanJianJieViewController alloc]init]]];
    
    [list addObject:[self getMenuItem:@"合作商家地址" withVC:[[HeZuoShangJiaAddrViewController alloc]init]]];
    
    return list;
}


//得到一个菜单项
-(NSDictionary *)getMenuItem:(NSString *)menu_title withVC:(UIViewController *)vc
{
    NSMutableDictionary *item=[[NSMutableDictionary alloc]initWithCapacity:2];
    [item setObject:menu_title  forKey:data_name];
    [item setObject:vc forKey:key_to_vc];
    
    return item;
}



//--------------------
//SRrcer菜单项部分
//--------------------
-(NSArray *)SRrcerMenuData
{
    NSMutableArray *list=[[NSMutableArray alloc]initWithCapacity:5];
    
    
    [list addObject:[self getMenuItem:@"SRMS-6F" withVC:[self getSRrcerDetailVc:@"SRMS-6F"]]];
    
    [list addObject:[self getMenuItem:@"SRS-6F" withVC:[self getSRrcerDetailVc:@"SRS-6F"]]];
    
    [list addObject:[self getMenuItem:@"SRB-61" withVC:[self getSRrcerDetailVc:@"SRB-61"]]];
    
    [list addObject:[self getMenuItem:@"SRB-81" withVC:[self getSRrcerDetailVc:@"SRB-81"]]];
    
    [list addObject:[self getMenuItem:@"SRB-82" withVC:[self getSRrcerDetailVc:@"SRB-82"]]];
    
    [list addObject:[self getMenuItem:@"SR-4R" withVC:[self getSRrcerDetailVc:@"SR-4R"]]];
    [list addObject:[self getMenuItem:@"SR-6R" withVC:[self getSRrcerDetailVc:@"SR-6R"]]];
    
    return list;
}


//得到SRrcer的详情控制器
-(SRrcerDetailViewController *)getSRrcerDetailVc:(NSString *)param
{
    SRrcerDetailViewController *vc=[[SRrcerDetailViewController alloc]init];
    vc.param=param;
    return vc;
}




//------------------
//---BC菜单数据项部分
//------------------
-(NSArray *)BCData
{
    NSMutableArray *list=[[NSMutableArray alloc]initWithCapacity:5];
    
    //默认轮圈车照
    NSArray *defaultData=[[NSArray alloc]init];
    
    LunQuanCheZhaoViewController *lunQuanCheZhao=[[LunQuanCheZhaoViewController alloc]init];
    
    NSMutableDictionary *item=[[NSMutableDictionary alloc]initWithCapacity:2];
    [item setObject:@"轮圈车照"  forKey:data_name];
    [item setObject:lunQuanCheZhao forKey:key_to_vc];
    
    [list addObject:item];
    
    
    [list addObject:[self getBCMenuItem:@"产品类别" withVC:[[UIViewController alloc]init] withNextMenuList:[self getProductCateList]]];

    
    return list;
}


//得到产品类别项
-(NSDictionary *)getBCMenuItem:(NSString *)menu_title withVC:(UIViewController *)vc withNextMenuList:(NSArray *)nextMenuList
{
    NSMutableDictionary *item=[[NSMutableDictionary alloc]initWithCapacity:2];
    [item setObject:menu_title  forKey:data_name];
    [item setObject:nextMenuList forKey:next_menu_list];
    [item setObject:vc forKey:key_to_vc];
    
    return item;
}


//产品类别菜单列表
-(NSArray *)getProductCateList
{
    NSMutableArray *list=[[NSMutableArray alloc]initWithCapacity:5];
    
    NSDictionary *defaultItem=[[NSDictionary alloc]init];
    
    
    [list addObject:[self getThirdMenuItem:@"HB" withVC:[self getDetailVC:@"BC"] withParam:defaultItem]];
    [list addObject:[self getThirdMenuItem:@"HC" withVC:[self getDetailVC:@"HC"] withParam:defaultItem]];
    [list addObject:[self getThirdMenuItem:@"RS" withVC:[self getDetailVC:@"RS"] withParam:defaultItem]];
    
    [list addObject:[self getThirdMenuItem:@"RT" withVC:[self getDetailVC:@"RS"] withParam:defaultItem]];
    [list addObject:[self getThirdMenuItem:@"SN" withVC:[self getDetailVC:@"RS"] withParam:defaultItem]];
    [list addObject:[self getThirdMenuItem:@"FJ" withVC:[self getDetailVC:@"RS"] withParam:defaultItem]];
    [list addObject:[self getThirdMenuItem:@"SR" withVC:[self getDetailVC:@"RS"] withParam:defaultItem]];
    [list addObject:[self getThirdMenuItem:@"BS" withVC:[self getDetailVC:@"RS"] withParam:defaultItem]];
    [list addObject:[self getThirdMenuItem:@"HB-R" withVC:[self getDetailVC:@"RS"] withParam:defaultItem]];
    
    return list;
}

//得到一个详情VC
-(DetailViewController *)getDetailVC:(NSString *)detailName
{
    DetailViewController *bc=[[DetailViewController alloc]init];
    bc.detail_cate_name=detailName;
    
    return bc;
}

//得到第三级菜单项
//得到一个菜单项
-(NSDictionary *)getThirdMenuItem:(NSString *)menu_title withVC:(UIViewController *)vc  withParam:(NSDictionary *)param
{
    NSMutableDictionary *item=[[NSMutableDictionary alloc]initWithCapacity:2];
    [item setObject:menu_title  forKey:data_name];
    [item setObject:vc forKey:key_to_vc];
    [item setObject:param forKey:menu_item_param];
    
    return item;
}



//--------------------
//BC-other菜单项部分
//--------------------
-(NSArray *)BCOtherMenuData
{
    NSMutableArray *list=[[NSMutableArray alloc]initWithCapacity:5];
    
    
    [list addObject:[self getMenuItem:@"BR" withVC:[self getBCOtherDetailVc:@"BR"]]];
    
    [list addObject:[self getMenuItem:@"V1" withVC:[self getBCOtherDetailVc:@"V1"]]];
    
    [list addObject:[self getMenuItem:@"RM" withVC:[self getBCOtherDetailVc:@"RM"]]];
    
    [list addObject:[self getMenuItem:@"ER" withVC:[self getBCOtherDetailVc:@"ER"]]];
         return list;
}


//得到SRrcer的详情控制器
-(BCOtherDetailViewController *)getBCOtherDetailVc:(NSString *)param
{
    BCOtherDetailViewController *detailVc=[[BCOtherDetailViewController alloc]init];
    detailVc.param=param;
    
    return detailVc;
}


@end
