//
//  MenuView.h
//  carfun
//
//  Created by Piosa on 14-5-29.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyButton.h"
#import "ItemView.h"
#import "MenuData.h"
#import "CustomImagePickerController.h"
#import "CarFanCustomImagePickerControllerViewController.h"

#import "UIImage+fixOrientation.h"
#import "UIImagePickerController+MyUIImagePickerController.h"

@interface MenuView : UIView
{
   
    
    //视图第一次到第三层
    ItemView *layerOne;
    
    ItemView *layerTwo;
    
    ItemView *layerThree;
    
   
    
    //第一级视图的Frame
    CGRect first_grade_frame;
    
    CGRect default_second_grade_frame;
    
    CGRect default_three_grade_frame;
    
    
    
    //默认的列表位置
    CGRect defaultFrame;
    
    //第二层的默认框架尺寸
    CGRect  secondDefaultFrame;

    UIView *currentSuperView;
    
    //触屏事件
    UITapGestureRecognizer *tapGesture;
    
}


-(id)initWithFrame:(CGRect)frame withSuperView:(UIView *)superView;


-(void)setMenuFrame:(CGRect)menuFrame;

//显示的菜单列表
@property(nonatomic,strong) UIView *leftContainer;

//菜单按钮
@property(nonatomic,strong) UIButton *menuBtn;

//菜单按钮的位置
//点击出现左菜单的按钮
@property CGRect leftFrame;

//如果当前是在照相控制其中调用需赋值
@property(nonatomic,strong) CarFanCustomImagePickerControllerViewController *carFanController;

//当前视图所在的UIViewController
@property(nonatomic,strong) UIViewController *uiViewController;

//添加左按钮
-(void)addLeftMenu;

@property(nonatomic,strong) UIButton *rightMenu;

// CarFanCustomImagePickerControllerViewController
@property(nonatomic,strong) CarFanCustomImagePickerControllerViewController *imagePickerController;

//第一层的数据
@property(strong,nonatomic) NSMutableArray *dataA;

//第二层的数据
@property(strong,nonatomic) NSMutableDictionary *dataB;

//第三层的数据
@property(strong,nonatomic) NSMutableDictionary *dataC;

//背景
@property(strong,nonatomic) UIImageView *background;


//临时区别视图控制器标签
@property(strong,nonatomic) UILabel *distinguishLbl;

//根据传入的视图清空里面所有的子视图
-(void)removeAllSubViews:(UIView *)view;

-(void)setOriention;

//跳转到照相页面
-(void)pushToTakePhoto:(CarFanCustomImagePickerControllerViewController *)imagePickerController;

-(void)showLeft;

-(void)hideMenu;

 
 


@end
