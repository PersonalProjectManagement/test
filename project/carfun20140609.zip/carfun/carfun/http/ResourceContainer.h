//
//  ResourceContainer.m
//  newBuyTicket
//
//  Created by Piosa on 14-1-15.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//


#import "ASIHTTPRequest.h"
#import "AppDelegate.h"
#import "ASIDownloadCache.h"
@interface ResourceContainer : NSOperation
{
    NSURL*_resourceURL;            //资源请求url
    NSObject*_hostObject;
    SEL _resourceDidReceive;      //资源接手响应方法
    
    ASIHTTPRequest*_httpRequest;
    UIImageView*_imageView;
    
    
   
}
@property (nonatomic, retain) NSURL*resourceURL;
@property (nonatomic, retain) NSObject*hostObject;

@property (nonatomic, assign) SEL resourceDidReceive;

@property (nonatomic, retain) ASIHTTPRequest*httpRequest;
@property (nonatomic, retain) UIImageView*imageView;

//http请求回调方法
-(void)didStartHttpRequest:(ASIHTTPRequest *)request;
-(void)didFinishHttpRequest:(ASIHTTPRequest *)request;
-(void)didFailedHttpRequest:(ASIHTTPRequest *)request;
//取消资源请求
-(void)cancelReourceGet;
//资源接收回调方法
-(void)resourceDidReceive:(NSData *)resource;

@end

