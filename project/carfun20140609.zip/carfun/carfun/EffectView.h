//
//  EffectView.h
//  carfun
//
//  Created by Piosa on 14-5-21.
//  Copyright (c) 2014年 com.jdtx. All rights reserved.
//

#import <UIKit/UIKit.h>
#define RATE  1.5

#define IMG_TAG 100

//文本容器tag
#define TXT_TAG  101

@interface EffectView : UIView<UIScrollViewDelegate>
{
    //背景视图
    UIImageView *bgView;
    
    //滚动视图
    UIScrollView *scrollView;
    
    //介绍文本
    UILabel *lbl;
    
    //产品图片
    UIImageView *productImage;
    
    //包含介绍文本的滚动视图
    UIScrollView *lblScrollView;
    
    CGRect productImgFrame;
    
    CGPoint point;
    
    //滚动的比例
    float imgRate;
    
    //参数
    NSArray *params;
    
    //文本容器多增加的高度
    float txtAdditionH;
    
    
    //当滑动到第二页时，图片移动到左面的距离
    float distance;
    
    //默认商品图片的x坐标
    float defaultImgX;
    
    //滚动视图文本向上移动的y坐标
    float scrollViewMoveUpY;
}

-(id)initWithFrame:(CGRect)frame withProductImgFrame:(CGRect)pimgFrame withData:(NSArray *)_params;

//设置图片到文字的右面
-(void)setProductImgDefault;

//根据传入的y坐标移动文本和图片,当第二页切换到第一页的时候
-(void)moveUp:(float)y;

//根据传入的y坐标移动文本和图片,当第二页切换到第一页的时候
-(void)moveDown:(float)y;

//设置滚动视图的偏移量为0，有坐标向上滚动一段距离
-(void)setScrollViewTxtOffsetAndY;
@end
